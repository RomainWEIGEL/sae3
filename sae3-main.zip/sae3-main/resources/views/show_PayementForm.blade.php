<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Formulaire de paiement</title>
</head>
<body>
    
    <form action="process_payment.php" method="post">
        <label for="card_number">Numéro de carte:</label>
        <input type="text" id="card_number" name="card_number" placeholder="Enter card number" required><br><br>
        
        <label for="expiry_date">Date d'expiration:</label>
        <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YYYY" required><br><br>
        
        <label for="cvv">Cryptogramme:</label>
        <input type="text" id="cvv" name="cvv" placeholder="CVV" required><br><br>
        
        <label for="name_on_card">Name on Card:</label>
        <input type="text" id="name_on_card" name="name_on_card" placeholder="Name on card" required><br><br>
        
        <input type="submit" value="Pay Now">
    </form>
</body>
</html>