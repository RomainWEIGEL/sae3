<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProgresSequence extends Model
{
    use HasFactory;
    protected $table = "progres_sequence";
    protected $primaryKey = null;
    public $incrementing = false;
    public $timestamps = false;

    
    protected $fillable = [
        "idutilisateur",
        "idsequence",
        "termine",
        "datefin"
    ];
    public function User()
    {
        return $this->belongsTo(User::class, 'idutilisateur', 'idutilisateur');
    }

    public function Date(){
        return $this->belongsTo(Date::class, 'datefin', 'iddate');
    }
}
