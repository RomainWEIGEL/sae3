<?php

namespace App\Http\Controllers;

use App\Models\HistoriqueFormation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HistoriqueFormationController extends Controller
{
    public function createHistoriqueFormation(Request $request) {
        $idformation = $request->idformation;
        $date = $request->date;
        HistoriqueFormation::create([
            'idutilisateur' => Auth::user()->idutilisateur,
            'idformation' => $idformation,
            'dateHeure'=> $date
        ]);
    }
}
