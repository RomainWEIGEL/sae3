<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>SkillUpNow</title>

    <!-- Les liens vers les bibliothèques jQuery et le fichier JavaScript de votre application -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Vérification de la présence du message de succès
            @if(session('success'))
                // Affichage de la popup avec le message de succès

                alert('{{ session('success') }}');
                //console.log('{{Auth::user()}}');
                document.location.href="{{URL::to('/connexioncompte')}}";

                /*$_POST.forEach(post => {
                    console.log(post);
                });*/
                // $.post('/connexioncompte', { createdEmail: 'value1'}, function(result) {
                // alert('successfully posted');});
            @endif
        });
    </script>

</head>
<body>
    
    <?php include(app_path().'/includes/mainBar.php'); ?>

    {{-- TEST FORMULAIRE ICI --}}
        <form action="{{ route("/login") }}" method="POST" class="form" id="connectForm" style="display: none;>
            @csrf
            <span id="croix">[ X ]</span>
            <h1 id="creationcomptetitre" class="signup"> Se Connecter </h1> 
            <div id="mailCreationCompte">
                <label for="mailutilisateur">E-mail :</label><br>
                <input type="email" id="mailutilisateur" name="mailutilisateur"  placeholder="exemple@domaine.com" maxlength="75" required class="form--input" ><br>
            </div>
        
            <div id="mdpCreationCompte">
                <label for="passwd">Mot de passe :</label><br>
                <input type="password" id="passwd" name="passwd" required class="form--input" ><br>
            </div>
        
            <input type="submit" value="Se connecter" class="form--submit">
            <p class="texteConnect">Vous ne possédez pas de compte? <a href="/creationcompte">Créer un compte</a></p>
        </form>
    {{-- FIN TEST FORMULAIRE --}}

    <!-- echo Hash::make("hop"); -->
    <div class="forma">
        @foreach ($formations as $formation)
            <div class="unselectable formation" id="{{$formation->idformation}}">
                <img class="formationImg" src="" alt="">
                <div class="textBlock">
                @if($formation->prixformation == 0)
                    <h2 class="formationTitle" >{{$formation->titreformation}} - Gratuite</h2>
                    <h2></h2>
                @else
                    <h2 class="formationTitle">{{$formation->titreformation}} <br> {{$formation->prixformation}} €</h2>
                @endif
                @if (strlen($formation->resumeformation) < 170)
                    <p class="textLigne">{{$formation->resumeformation}}</p>
                @else
                    <p class="textLigne">{{substr($formation->resumeformation, 0, 170)}}...</p> 
                @endif
                <p class="textLigne interVenant"> <b>Intervenants </b> : {{$formation->intervenant->nomintervenant}}</p>
                <div class="interVenantPopup "><p class="underline">{{$formation->intervenant->nomintervenant}} {{$formation->intervenant->prenomintervenant}}</p> {{$formation->intervenant->resumeintervenant}}</div>
        <p><a href="/concepteur/{{$formation->idconcepteur}}"><b>Concepteur </b> : {{$formation->concepteur->nomecole}}</a></p>
                <p class="textLigne"> <b>Niveau </b> : {{$formation->niveauformation->nomniveau}}</p>
                </div>
            </div>
         @endforeach
    </div>
  
    <?php include(app_path().'/includes/footer.php'); ?>
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    {{--<script src="{{ asset('js/cookies.js') }}"></script>--}}
</body>
</html>