<?php

namespace App\Http\Controllers;

use App\Models\CodeEtat;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UtilisateurController extends Controller
{
    /** GET UTILISATEURS
     * Récupère tous les utilisateurs
     */
    public function getUtilisateur(){
        $utilisateurs = User::all();

        return view('utilisateurs', ["utilisateurs"=> $utilisateurs]);
    }

    /** SHOW UTILISATEUR
     * Récupère uniquement l'utilisateur dont l'ID est spécifié en paramètre
     * 
     * @param {Request} $request -> requête envoyé
     * @param {integer} $id -> id de l'utilisateur
     */
    public function showUtilisateur(Request $request, $id){
        $utilisateur = User::findOrFail($id);

        return view("showUtilisateur", ["utilisateur" => $utilisateur]);
    }
    
    /** CREATE USER
     * Permet de créer un utilisateur selon la requête envoyée (venant d'un formulaire) 
     * @see creation_Utilisateur.blade.php
     */
    public function createUser(Request $request){

        $validatedData = $request->validate([
            'nomutilisateur' => ['nullable', 'string'],
            'prenomutilisateur' => ['nullable', 'string'],
            'mailutilisateur' => ['required', 'string', 'unique:utilisateur,mailutilisateur'] ,
            'mdpu' => ['required', 'string'],
            'codecommune' => ['nullable', 'integer']
        ]);
        try{
            $user = User::create($validatedData);
           
            CodeEtat::create([
                "idUtilisateur"=>$user->idutilisateur,
                "NomEtat"=>$request->input('choix')
            ]);
            
        return redirect("/")->with('success', 'Compte créé avec succès!');
        } catch (Exception $e){
            return redirect("/creationcompte")->withInput()->withErrors(['error' => 'Une erreur est survenue lors de la création de votre compte. Veuillez réessayer.']);
        }



        


        

    }

    /** UPDATE USER
     * Permet de mettre à jour les informations de l'utilisateur selon l'ID qui a été fourni.
     *
     *  @see dashboard.blade.php
     */ 
    public function updateUser(Request $request){
        $id = Auth::user()->idutilisateur;
     
        #Match The Old Password
        if(Hash::check(bcrypt(Auth::user()->mdpu), bcrypt($request->mdpu))){
            return back()->with("error", "Old Password Doesn't match!");
        }

        #Update the new Password
        User::findOrFail($id)->update([
            'mdpu' => Hash::make($request->mdpu)
        ]);

        $user = User::findOrFail($id);

        $validatedData = $request->validate([
            'nomutilisateur' => ['nullable', 'required', 'string'],
            'prenomutilisateur' => ['nullable', 'required', 'string'],
            'mailutilisateur' => ['required', 'string'],
            'codecommune' => ['nullable', 'integer']
        ]);

        $user->update($validatedData);
        
        
        return redirect("/dashboard");
    }

    
}
