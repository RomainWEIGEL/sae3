<?php

namespace App\Http\Controllers;

use App\Models\Sequence;
use Illuminate\Http\Request;

class SequenceController extends Controller
{
    public function getSequence($id){
        return Sequence::findOrFail($id);
    }

}
