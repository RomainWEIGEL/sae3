<?php

namespace App\Http\Controllers;

use App\Models\lien_formation_sequence;
use App\Models\Sequence;
use Illuminate\Http\Request;

class LienformationsequenceController extends Controller
{
    public function getSequenceFormation($idsequence, $idformation){
        $sequence = lien_formation_sequence::where('idsequence', $idsequence)
                                            ->where('idformation', $idformation)
                                            ->first();
        return $sequence;
    }
}
