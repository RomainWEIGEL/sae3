<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Categorie_Formation extends Model
{
    use HasFactory;
    protected $table = "categorie_formation";
    protected $primaryKey = null;
    public $timestamps = false;
    public $incrementing = false;

    protected $fillable = [
        "idformation",
        "idcategorie"
    ];


    
    // public function categorie()
    // {
    //     return $this->belongsTo(Categorie::class, 'idcategorie');
    // }

    // public function formation()
    // {
    //     return $this->belongsTo(Formation::class, 'idformation');
    // }
}
