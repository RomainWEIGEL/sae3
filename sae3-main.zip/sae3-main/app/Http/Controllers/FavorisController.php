<?php

namespace App\Http\Controllers;

use App\Models\Favoris;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class FavorisController extends Controller
{
    public function createFavoris(Request $request) {
        $validatedData = $request->validate([
            'idutilisateur' => ['required', 'integer'],
            'idformation' => ['required', 'integer']
        ]);
    
        $userId = $validatedData['idutilisateur'];
        $formationId = $validatedData['idformation'];
    
        // Vérifier si ce favori existe déjà pour cet utilisateur et cette formation
        $existingFavori = Favoris::where('idutilisateur', $userId)
            ->where('idformation', $formationId)
            ->first();
    
        if (!$existingFavori) {
            // Si le favori n'existe pas, créez-le
            Favoris::create($validatedData);
        }
    
        return back();
    }

    public function deleteFavoris(Request $request, $idformation, $idutilisateur){
        DB::table('favoris')
        ->where('idformation', $idformation)
        ->where('idutilisateur', $idutilisateur)
        ->delete();
        return back();
    }
}
