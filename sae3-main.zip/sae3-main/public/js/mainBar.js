let logo = document.querySelector("img#logo");
let mainBarFormations = document.querySelector("#mainBarFormations");
let mainBarCategories = document.querySelector("#mainBarCategories");
let mainBarThematiques = document.querySelector("#mainBarThematiques");
let mainBarCompte = document.querySelector("#compteDiv");
let seConnecterDiv = document.querySelector("#seConnecterDiv");
let connectPopup = document.querySelector("#connectForm");
let modif = document.querySelector("#show_formation");
let toMenuConcepteurDiv = document.querySelector("#divBtnMenuConcepteur");

let isConnectPopupOpened = false;

logo.addEventListener("click", ()=>{
    document.location.href="/";
});

//modif.addEventListener("click", ()=>{
    //document.location.href="/dash";
//});

// mainBarFormations.addEventListener("click", ()=>{
//     document.location.href="/formation";
//     document.getElementById('connectForm').style.display = 'none';
// });

mainBarCategories.addEventListener("click", ()=>{
    document.location.href="/categorie";
});

mainBarThematiques.addEventListener("click", ()=>{
    document.location.href="/thematiques";
});
/*
mainBarCompte.addEventListener("click", ()=>{
    document.location.href="/creationcompte";
});
*/
if(toMenuConcepteurDiv != null){
    toMenuConcepteurDiv.addEventListener("click", ()=> {
        document.location.href="/proposer_formation";
    })
}

seConnecterDiv.addEventListener("click", ()=>{
    
    let textConnect = document.getElementById("textCreateUser");
    var contenuEnMinuscules = textConnect.innerHTML.toLowerCase();
    console.log(textConnect.textContent);
    
    if (textConnect.textContent == "Se Connecter"){
        document.location.href="/connexioncompte"}
        else if(contenuEnMinuscules == "admin"){
            document.location.href="/dashboardadmin"

        }
        else if(contenuEnMinuscules == "concepteur"){
            document.location.href="/dashboardconcepteur"

        }
        else {
            document.location.href="/dashboard"
        }
    

    // if (document.querySelector("#textCreateUser").textContent == "Se Connecter" ) {
    //     document.getElementById('connectForm').style.display = 'block';
    //     console.log("seconnecter click");

    //     if(!isConnectPopupOpened){
    //         connectPopup.style.display = "block";
    //     }

    //     let croix = document.querySelector("#croix");
        
    //     croix.addEventListener("click", ()=>{
    //         //let popupConnectt = document.querySelector(".popup");
    //         //console.log(popupConnectt);
    //         console.log("clique croix");
    //         //popupConnectt.remove();
    //         connectPopup.style.display = "none";
    //         isConnectPopupOpened = false;
    //     });
    
    //     isConnectPopupOpened = true;

    // }
    
})
