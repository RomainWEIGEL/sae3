<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Parcours extends Model
{
    use HasFactory;

    protected $table = "parcours";
    protected $primaryKey = "idparcours";
    public $timestamps = false;

    
    protected $fillable = [
        "titreparcours",
        "resumeparcours",
        "datefinparcours",
        "datedebutparcours"
    ];

    public function formations()
    {
        return $this->belongsToMany(Formation::class, 'lien_parcours_formation', 'idparcours', 'idformation')->orderByPivot('lien_parcours_formation.indexformation', 'asc');
    }

    public function dateFinFormation()
    {
        return $this->belongsTo(Date::class, 'datefinparcours', 'iddate');
    }

    public function dateDebutFormation()
    {
        return $this->belongsTo(Date::class, 'datedebutparcours', 'iddate');
    }

    public function certification()
    {
        return $this->belongsTo(Certification::class, 'idcertification', 'idcertification');
    }

    public function langue()
    {
        return $this->belongsTo(Langue::class, 'idlangue', 'idlangue');
    }
}
