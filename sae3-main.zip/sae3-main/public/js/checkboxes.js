const summaryElements = document.querySelectorAll('summary');

// Loop through each selected element and log their details
summaryElements.forEach(item => {
    item.innerHTML += ''+
    '<br>'+
    '<?php'+
       ' // CHECKBOXES'+
        "$progresSequence = App\\Models\\ProgresSequence::where('idsequence', $seq->idsequence)"+
            "->where('idutilisateur', Auth::user()->idutilisateur)"+
            "->first();"+

        "echo '<input id="+'ckFinit'+'.$seq->idsequence.'+" type="+'checkbox'+" name="+'sequence_ids[]+'+" value="+' . $seq->idsequence . '+"';"+
        "// Vérifier si la séquence est marquée comme terminée pour l'utilisateur"+
        "if ($progresSequence && $progresSequence->termine == 'OUI') {"+
            "echo ' checked';}"+
        "echo '>';"+
    "?>"+
    '<label for="ckFinit{{$seq->idsequence}}"> J\'ai terminé</label>'+
'</details>'
});