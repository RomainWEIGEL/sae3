<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InscriptionFormation extends Model
{
    use HasFactory;

    protected $table = "inscription_formation";
    protected $primaryKey = "idinscriptionformation";
    public $incrementing = true;
    public $timestamps = false;

    
    protected $fillable = [
        "idutilisateur",
        "idformation",
        "referencereglement",
        "dateinscriptionformation"
    ];

    public function reglement()
    {
        return $this->belongsTo(Reglement::class, 'referencereglement', 'referencereglement');
    }

    public function dateInscriptionFormation(){
        return $this->belongsTo(Date::class, 'iddate', 'dateinscriptionformation');
    }

    public function formationenseigne(){
        return $this->belongsTo(Formation::class, 'idformation', 'idformation');
    }
}
