<?php

namespace App\Http\Controllers;

use App\Models\Parcours;
use App\Models\Domaine_Formation;
use Illuminate\Http\Request;

class ThematiquesController extends Controller
{
    public function getThematiques(){
        $thematiques = Domaine_Formation::all();
        return view('thematiques', ["thematiques"=> $thematiques]);
    }

    public function showParcours(Request $request, $id)
{
    $thematique = Domaine_Formation::findOrFail($id);
    $formationsDuDomaine = $thematique->formations;
    $parcours = [];
    $parcoursIDs = [];

    foreach ($formationsDuDomaine as $formation) {
        if ($formation->iddomaine == $thematique->iddomaine) {
            foreach ($formation->parcours as $parcour) {
                // Correction ici : in_array prend la valeur en premier et le tableau en second
                if (!in_array($parcour->idparcours, $parcoursIDs)) {
                    array_push($parcoursIDs, $parcour->idparcours);
                    array_push($parcours, $parcour); // On récupère les parcours où elle se situe
                }
            }
        }
    }

    return view("parcours_par_thematiques", ["parcours" => $parcours, "thematique" => $thematique]);
}
}
