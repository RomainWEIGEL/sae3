<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sequence extends Model
{
    use HasFactory;
    protected $table = "sequenceformation";
    protected $primaryKey = "idsequence";
    public $timestamps = false;

    
    protected $fillable = [
        "nomsequence",
        "resumesequence",
        "dureesequence",
        "cheminressourcesequence"
    ];
    public function formations()
    {
       return $this->belongsToMany(Formation::class, 'lien_formation_sequence', 'idsequence', 'idformation');
    }
}
