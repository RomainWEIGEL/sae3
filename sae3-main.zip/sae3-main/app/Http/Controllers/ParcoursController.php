<?php

namespace App\Http\Controllers;

use App\Models\FavorisParcours;
use Illuminate\Http\Request;
use App\Models\Parcours;
use Illuminate\Support\Facades\Auth;

class ParcoursController extends Controller
{
    public function showParcours(Request $request, $id){

        $parcours = Parcours::findOrFail($id);

        return view("show_parcours", ["parcours" => $parcours]);
        //"utilisateurs"=>$utilisateur
    }
    public function addToFavoritesParcours(Request $request) {
    
        $userId = Auth::user()->idutilisateur;
        $parcoursId = (int)$request->favpar;

        // Vérifier si ce favori existe déjà pour cet utilisateur et cette formation
        $existingFavori = FavorisParcours::where('idutilisateur', $userId)
            ->where('idparcours', $parcoursId)
            ->first();
    
        if (!$existingFavori) {
            // Si le favori n'existe pas, créez-le
            FavorisParcours::create([
                "idutilisateur"=>$userId,
                "idparcours"=>$parcoursId
            ]);
        }
    
        return back();
    }
}
