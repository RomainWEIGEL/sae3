<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Ville;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class DashboardController extends Controller
{
    public function getVilles(){
        $villes = Ville::all();
        $user = User::all();
        
        return view('/dashboard', ["villes"=> $villes, "user" => $user]);
    }

   

    public function showVille(Request $request, $codeINSEE){
        $ville = Ville::findOrFail($codeINSEE);

        return view("villes", ["ville" => $ville]);
    }
        
    public function createVille(Request $request){
        $validatedData = $request->validate([
            'codeINSEE' => ['required', 'string'],
            'codepays' => ['required', 'string'],
            'nomville' => ['required', 'string'],
            'codePostal' => ['required', 'string']

        ]);
        
        Ville::create($validatedData);
        
        return redirect("/");
    }

    
}
