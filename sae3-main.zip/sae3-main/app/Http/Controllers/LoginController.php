<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use \App\Models\Utilisateur;
use \App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Hash;

use function Laravel\Prompts\error;

class LoginController extends Controller
{
    /**
     * Essaye d'authentifier un utilisateur
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function authenticate(Request $request)
    {

        $credentials = $request->validate([
            'mailutilisateur' => ['required'],
            'passwd' => ['required'],
        ]);

        unset($credentials["passwd"]);
        $credentials["password"] = $request->passwd;


        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended('/dashboard');
        }

        return back
    ()->withErrors([
            'email' => 'Mauvais identifiant ou mot de passe.',
        ]);
}
    /**
    * Déconnecte un utilisateur déjà connecté.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return \Illuminate\Http\Response
    */
    public function logout(Request $request) {
        Auth::logout();
        return redirect('/');
    }
}