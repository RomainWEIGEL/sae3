<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>SkillUpNow</title>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>
    
    <h1>{{$thematique->nomdomaine}}</h1>
    @if($parcours != null)
        <div class="forma">
            @foreach ($parcours as $parcour)
            <div class="unselectable parcours" id="{{$parcour->idparcours}}">
                <img class="formationImg" src="" alt="">
                <div class="textBlock"></div>
                    <h2 class="formationTitle" >{{$parcour->titreparcours}}</h2>
                    <?php
                        {{$prixTotal = 0;}}
                        foreach($parcour->formations as $form){
                            $prixTotal += $form->prixformation;
                        }
                        echo "<h3>{$prixTotal} €</h3>";
                    ?>
                    <h3>{{$parcour->langue->nomlangue}}</h3>
                @if (strlen($parcour->resumeparcours) < 170)
                    <p class="textLigne">{{$parcour->resumeparcours}}</p>
                @else
                    <p class="textLigne">{{substr($parcour->resumeparcours, 0, 170)}}...</p> 
                @endif
            </div> 
            @endforeach
        </div>
    @else
        <p>Pas encore de parcours pour cette thématique</p>
    @endif 

    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
</body>
</html>