<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Domaine_Formation extends Model
{
    use HasFactory;
    protected $table = "domaine_formation";
    protected $primaryKey = "iddomaine";
    public $timestamps = false;

    
    protected $fillable = [
        "nomdomaine",
        "descriptiondomaine"
    ];

    public function formations()
    {
        return $this->hasMany(Formation::class, 'iddomaine', 'iddomaine');
    }
    
}
