<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Intervenant extends Model
{
    use HasFactory;
    protected $table = "intervenant";
    protected $primaryKey = "idintervenant";
    public $timestamps = false;

    
    protected $fillable = [
        "nomintervenant",
        "prenomintervenant",
        "mailintervenant",
        "resumeintervenant",
        "mdpi"
    ];
    // Relation avec les formations
    public function formations()
    {
        return $this->hasMany(Formation::class, 'idintervenant', 'idintervenant','resumeintervenant');
    }
}
