<?php

use App\Http\Controllers\AvisController;
use App\Http\Controllers\FormationController;
use App\Http\Controllers\UtilisateurController;
use App\Http\Controllers\CategorieController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\VilleController;
use App\Http\Controllers\ConcepteurController;
use App\Http\Controllers\DashboardAdminController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Categorie_FormationController;
use App\Http\Controllers\FavorisController;
use App\Http\Controllers\ThematiquesController;
use App\Http\Controllers\accueilController;
use App\Http\Controllers\CodeEtatController;
use App\Http\Controllers\HistoriqueFormationController;
use App\Http\Controllers\InscriptionformationController;
use App\Http\Controllers\ParcoursController;
use App\Http\Controllers\ProgresSequenceController;
use App\Models\CodeEtat;
use Illuminate\Support\Facades\Route;
use SebastianBergmann\CodeCoverage\Report\Html\Dashboard;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

/*
|------------------------------------
| Formations
|------------------------------------
*/
Route::get('/formation', [FormationController::class, "getFormations"]);
Route::get('/formation/{id}', [FormationController::class, "showFormation"]); // url selon id


Route::post('/favoris', [FormationController::class, "addToFavorites"])->name("/favoris");
Route::delete('/favoris/delete/{idformation}-{idutilisateur}', [FavorisController::class, "deleteFavoris"]);

Route::post('/inscriptionformation', [InscriptionformationController::class, "createInscription"])->name("/inscriptionformation");

Route::post('/saveProgressionFormation', [ProgresSequenceController::class, "updateProgres"])->name("/saveProgressionFormation");
/*
|------------------------------------
| Catégories
|------------------------------------
*/

Route::get('/categorie', [CategorieController::class, "getCategorie"]);
Route::get('/categorie/{id}', [Categorie_FormationController::class, "showCategorie_Formation"]);


/*
|------------------------------------
| Accueil
|------------------------------------
*/
Route::get('/',[accueilController::class, "getParcours"] );

/*
|------------------------------------
| Création de comptes
|------------------------------------
*/

Route::get('/creationcompte', [VilleController::class, "getVilles"]);
Route::post('/creationcompte', [UtilisateurController::class, "createUser"]);



/*
|------------------------------------
| Connection au Concepteur
|------------------------------------
*/
//Route::post('/creationcompte', [UtilisateurController::class, "createUser"]);

/*
|------------------------------------
| Connection au compte
|------------------------------------
*/
//Route::get('/show_dashboard', [VilleController::class, "getVilles"]);
Route::get('/connexioncompte', function () {
    return view('connexion_Utilisateur');
});
Route::get('/dashboardadmin', function () {
    return view('dashboard_Admin');
});
Route::get('/dashboard', function () {
    return view('dashboard');
});
Route::post('/update', [UtilisateurController::class, "updateUser"])->name("/update");


Route::post('/login', [LoginController::class, "authenticate"])->name("/login");
Route::get('/logout', '\App\Http\Controllers\LoginController@logout');




Route::get('/dashboard', [DashboardController::class, "getVilles"]);

Route::get('/dashboardadmin', [CodeEtat::class, "getCodeEtats"]);
Route::delete('/dashboardAdmin/delete/{idUtilisateur}-{nomEtat}', [DashboardAdminController::class, "deleteCodeEtat"]);
Route::post('/updateCompte/update/{idUtilisateur}', [DashboardAdminController::class, "updateCodeEtat"]);

/*
|------------------------------------
| Concepteur
|------------------------------------
*/
Route::get('/concepteur/{id}', [ConcepteurController::class, "showConcepteur"]); // url selon id
Route::get('/proposer_formation', [ConcepteurController::class, "showCreateFormation"]);
Route::post('/proposer_formation', [ConcepteurController::class, "createFormation"]);

// Politique protection de donnees personnelles

Route::get('/politique_protection_donnees_personnelles', function () {
    return view('politique_protection_donnees_personnelles');
});

/* THEMATIQUES PARCOURS */
Route::get('/thematiques', [ThematiquesController::class, "getThematiques"]);
Route::get('/thematiques/{id}', [ThematiquesController::class, "showParcours"]);

/* PARCOURS */
Route::get('/parcours/{id}', [ParcoursController::class, "showParcours"]);
Route::post('/FavorisParcours', [ParcoursController::class, "addToFavoritesParcours"])->name("/FavorisParcours");

Route::post('/historiqueformation', [HistoriqueFormationController::class, "createHistoriqueFormation"]);

