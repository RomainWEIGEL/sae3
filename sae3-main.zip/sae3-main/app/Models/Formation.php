<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\CategorieFormation;

class Formation extends Model
{
    use HasFactory;
    
    protected $table = "formation";
    protected $primaryKey = "idformation";
    public $timestamps = false;

    
    protected $fillable = [
        "iddomaine",
        "idintervenant",
        "idconcepteur",
        "titreformation",
        "prixformation",
        "resumeformation",
        "datedebutformation",
        "datefinformation",
        "idlangue",
        "idniveau"
    ];
    // Relation avec les avis
    public function avis()
    {
        return $this->hasMany(Avis::class, 'idformation', 'idformation');
    }
    public function dateDebutFormation()
    {
        return $this->belongsTo(Date::class, 'datedebutformation', 'iddate');
    }
    public function dateFinFormation()
    {
        return $this->belongsTo(Date::class, 'datefinformation', 'iddate');
    }
    // Relation avec les lien_formation_sequence
    public function Sequence()
    {
        return $this->belongsToMany(Sequence::class, 'lien_formation_sequence', 'idformation', 'idsequence')->orderByPivot('lien_formation_sequence.indexsequence', 'asc');
    }
    // Relation avec les intervenants
    public function intervenant()
    {
        return $this->belongsTo(Intervenant::class, 'idintervenant', 'idintervenant');
    }
    public function concepteur()
    {
        return $this->belongsTo(Concepteur::class, 'idconcepteur', 'idconcepteur');
    }
    public function niveauformation()
    {
        return $this->belongsTo(NiveauFormation::class, 'idniveau', 'idniveau');
    }
    // public function categories()
    // {
    //     return $this->belongsToMany(Categorie::class)->withPivot('active');;
    // }
    public function domaine()
    {
        return $this->belongsTo(Domaine_Formation::class, 'iddomaine', 'iddomaine');
    }
    public function parcours()
    {
        return $this->belongsToMany(Parcours::class, 'lien_parcours_formation', 'idformation', 'idparcours');
    }
}
