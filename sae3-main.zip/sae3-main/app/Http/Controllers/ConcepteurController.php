<?php

namespace App\Http\Controllers;

use App\Models\Categorie;
use App\Models\Categorie_Formation;
use App\Models\Concepteur;
use App\Models\Intervenant;
use App\Models\Langue;
use App\Models\CodeEtat;
use App\Models\User;
use App\Models\Date;
use App\Models\Formation;
use App\Models\Domaine_Formation;
use App\Models\lien_formation_sequence;
use App\Models\NiveauFormation;
use App\Models\Sequence;
use Illuminate\Http\Request;
use Exception;

class ConcepteurController extends Controller
{
    public function showConcepteur(Request $request, $id){
        $concepteur = Concepteur::FindOrFail($id);
        return view('show_concepteur', ["concepteur"=>$concepteur]);
    }

    public function showCreateFormation(){
        $domaines = Domaine_Formation::all();
        $intervenants = Intervenant::all();
        $langues = Langue::all();
        $niveaux = NiveauFormation::all();
        $categories = Categorie::all();
        return view("proposer_formation", ["domaines"=>$domaines, "intervenants"=>$intervenants, "langues"=>$langues, "niveaux"=>$niveaux, "categories"=>$categories]);
    }

    public function createFormation(Request $request){
        //dd($request);

        // Creation et assignation de la date dans notre table date
        $dateDebut = Date::create([
            "date"=>$request->input('datedebutformation')
        ]);
        $dateFin = Date::create([
            "date"=>$request->input('datefinformation')
        ]);
        $request->merge(['datefinformation' => $dateFin->iddate, 'datedebutformation' => $dateDebut->iddate]);

        //dd($request);
        $validatedData = $request->validate([
            'iddomaine' => ['required'],
            'idintervenant' => ['required'],
            'idconcepteur' => ['required'],
            'titreformation' => ['required', 'string'],
            'prixformation' => ['required'],
            'resumeformation' => ['required', 'string'],
            'datedebutformation' => ['required'],
            'datefinformation' => ['required'],
            'idlangue' => ['required'],
            'idniveau' => ['required'],
        ]);
        //dd($validatedData);
        $formationCree = Formation::create($validatedData);

        // Ajout à une catégorie
        $categoriePivot = Categorie_Formation::create([
            "idformation"=>$formationCree->idformation,
            "idcategorie"=>$request->input('idcategorie')
        ]);

        // Sequences
        $nbSequences = $request->input('nbsequence');
        for ($i=1; $i < $nbSequences+1; $i++) { 
            $inputName = $i."_nomsequence";
            $inputResume = $i."_resumesequence";
            $inputDuree = $i."_dureesequence";
            $inputChemin = $i."_cheminressourcesequence";

            $nom = $request->input($inputName);
            $resume = $request->input($inputResume);
            $duree = $request->input($inputDuree);
            $chemin = $request->input($inputChemin);

            $sequence = Sequence::create([
                "nomsequence"=>$nom,
                "resumesequence"=>$resume,
                "dureesequence"=>$duree,
                "cheminressourcesequence"=>$chemin
            ]);
            //dd($sequence);
            
            $sequencePivot = lien_formation_sequence::create([
                "idformation"=>$formationCree->idformation,
                "idsequence"=>$sequence->idsequence,
                "indexsequence"=>$i
            ]);
        }
        
        return redirect("/")->with('succesformation', 'Formation créé avec succès!');
    }
}

/*
try{
            $formationCree = Formation::create($validatedData);
            dd($formationCree);
            
            CodeEtat::create([
                "idUtilisateur"=>$user->idutilisateur,
                "NomEtat"=>$request->input('choix')
            ]);
            
            return redirect("/")->with('success', 'Formation créé avec succès!');
        }catch (Exception $e){
            dd($formationCree);
            return redirect("/proposer_formation")->withInput()->withErrors(['error' => 'Une erreur est survenue lors de la création de votre compte. Veuillez réessayer.']);
        }
*/
