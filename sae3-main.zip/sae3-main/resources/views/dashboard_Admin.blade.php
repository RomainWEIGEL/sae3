<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tableau de bord utilisateur</title>
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleDashboard.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleFormation.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleparcours.css'); ?>">
</head>
<body>
    <?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <?php include(app_path().'/includes/mainBar.php'); ?>

    {{--SI L'UTILISATEUR N'EST PAS CONNECTE, ON LE REDIRIGE VERS LE FORMULAIRE DE CONNEXION--}}
    @if (Auth::guest())
        <script>window.location.href = "/connexioncompte";</script>
        <?php exit; ?>
    @endif

    @if (Auth::User()->CodeEtat->NomEtat != "admin" || !(Auth::User()->CodeEtat->etat))
    <script>window.location.href = "/dashboard";</script>
    <?php exit; ?>
    @endif

    <input class="button-19" type="button" onclick='window.location.href="/logout";' value="Se deconnecter">
    <details open>
        <summary><h2>Vos informations</h2></summary>
            <form method="POST" id="dashmodif" action="{{ route("/update") }}">
                @csrf

                <label for="nomutilisateur">Nom:</label>
                <br><input type="text" id="nomutilisateur" name="nomutilisateur" class="form--input" minlength='0' maxlength='75' pattern="[A-Za-zÀ-ÖØ-öø-ÿ\s'-]+" value="{{Auth::user()->nomutilisateur}}"><br>

                <label for="prenomutilisateur">Prénom:</label>
                    <br><input type="text" id="prenomutilisateur" name="prenomutilisateur" class="form--input" minlength='0' maxlength='50' pattern="[A-Za-zÀ-ÖØ-öø-ÿ\s'-]+" value="{{Auth::user()->prenomutilisateur}}"><br>

                @if (!Auth::user()->codecommuneL)<label for="codecommune">Ville: Non précisé</label><br>
                @else<label for="codecommune">Ville: {{Auth::user()->codecommuneL->nomville}}</label><br>
                @endif
                
                <input placeholder="Choisissez une ville" pattern="[0-9]{5}" type="text" id="codecommune" name="codecommune" value="{{Auth::user()->codecommune}}" class="form--input">
            
                {{-- Chargement des bibliothèques javascript jquery --}}
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
                <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
                
                {{-- Script d'affichage et d'autocomplétion des villes --}}
                <script>
                $(function() {
                    // TOUTES LES VILLES
                    const villes = [
                        @foreach ($villes as $ville)
                            { label: "{{$ville->nomville." (".$ville->codePostal.") "}}", value: "{{$ville->codecommune}}" },
                        @endforeach
                    ];
                    
                    // AUTOCOMPLETION
                    $('#codecommune').autocomplete({
                        // La source des données pour l'autocomplétion
                        source: function(request, response) {
                            // VERIFICATIONS:
                            // Échapper les caractères spéciaux pour éviter les problèmes de regex
                            const userInput = $.ui.autocomplete.escapeRegex(request.term);
                            // Expression régulière pour filtrer les résultats basés sur la saisie de l'utilisateur
                            const matcher = new RegExp('^' + userInput, 'i');
                            
                            // FILTRE:
                            // Réponse avec les éléments filtrés selon la saisie de l'utilisateur
                            response($.grep(villes, function(item) {
                                return matcher.test(item.label);
                            }));
                        },
                        // Nombre minimum de caractères avant de déclencher l'autocomplétion
                        minLength: 2 // Minimum de caractères avant de déclencher l'autocomplétion
                    });
                });
                </script>

                <br>
                <label for="mailutilisateur">Mail:</label>
                    <br><input type="email" id="mailutilisateur" name="mailutilisateur" class="form--input" minlength='5' maxlength='75' value="{{Auth::user()->mailutilisateur}}"><br>


                <label for="mdpu">Changer le mot de passe:</label>
                    <br><input type="password" id="mdpu" name="mdpu" minlength='12' class="form--input" value="{{Auth::user()->mdpu}}"><br>

                <input type="Submit" value="Modifier">
                
            </form> 
        </details>

        
        
       
        <div class="codeEtat">
            @foreach($codeEtats as $codeEtat)
                @if($codeEtat->NomEtat != "utilisateur" && $codeEtat->NomEtat != null)
              

                <div class="pouradmin" id="pouradmin">
                    <form method="POST" class="formformation" action="/dashboardAdmin/delete/{{$codeEtat->idUtilisateur}}">
                        @csrf @method('DELETE') 
                        <button type="submit" class="croixPourAdmin" value="{{$codeEtat}}">X</button>
                    </form>
                    <img class="imgpouradmin" src="img/utilisateur.png" alt="utilisateur.png">     
                    <h4>{{$codeEtat->User->mailutilisateur}}</h4>  
                    <br>        
                    
                    <form method="POST" action="/updateCompte/update/{{$codeEtat->idUtilisateur}}">
                        @csrf
                        <input type="Submit" value="Modifier Compte">
                    <div id="choixEtat">
                        <label for="choix">votre poste :</label>
                        <div id="nometatdiv">
                            <p class="nometat">{{$codeEtat ->NomEtat}}</p>
                        </div>

                        <input placeholder="NomEtat" type="text" id="code" name="code" class="form--input" value="{{$codeEtat->NomEtat}}">

                        
                        <script>
                            $(function() {
                                const codeetat = ["admin",
                                "concepteur"
                                ];

                                
                                // AUTOCOMPLETION
                                $('#code').autocomplete({
                                    // La source des données pour l'autocomplétion
                                    source: function(request, response) {
                                        // VERIFICATIONS:
                                        // Échapper les caractères spéciaux pour éviter les problèmes de regex
                                        const userInput = $.ui.autocomplete.escapeRegex(request.term);
                                        // Expression régulière pour filtrer les résultats basés sur la saisie de l'utilisateur
                                        const matcher = new RegExp('^' + userInput, 'i');
                                        
                                        // FILTRE:
                                        // Réponse avec les éléments filtrés selon la saisie de l'utilisateur
                                        response($.grep(codeetat, function(item) {
                                            return matcher.test(item.label);
                                        }));
                                    },
                                    // Nombre minimum de caractères avant de déclencher l'autocomplétion
                                    minLength: 0 // Minimum de caractères avant de déclencher l'autocomplétion
                                });
                            });
                        </script>

                            <label for="choix">l'Etat du compte :</label>
                            <div id="nometatdiv">
                                <p class="nometat">{{$codeEtat ->etat}}</p>
                            </div>

                            <input placeholder="NomEtat" type="boolean" id="codeetat" name="code" class="form--input" value="{{$codeEtat->etat}}">


                            <script>
                                $(function() {
                                    const codeetat = ["true", "false"];

                                    
                                    // AUTOCOMPLETION
                                    $('#codeetat').autocomplete({
                                        // La source des données pour l'autocomplétion
                                        source: function(request, response) {
                                            // VERIFICATIONS:
                                            // Échapper les caractères spéciaux pour éviter les problèmes de regex
                                            const userInput = $.ui.autocomplete.escapeRegex(request.term);
                                            // Expression régulière pour filtrer les résultats basés sur la saisie de l'utilisateur
                                            const matcher = new RegExp('^' + userInput, 'i');
                                            
                                            // FILTRE:
                                            // Réponse avec les éléments filtrés selon la saisie de l'utilisateur
                                            response($.grep(codeetat, function(item) {
                                                return matcher.test(item.label);
                                            }));
                                        },
                                        // Nombre minimum de caractères avant de déclencher l'autocomplétion
                                        minLength: 0 // Minimum de caractères avant de déclencher l'autocomplétion
                                    });
                                });
                            </script>
                        
                    </div>
                </form>
                </div>
   
               
                @endif
           
            @endforeach
        </div>

 
    <hr>

        <script src="{{ asset('js/review.js') }}"></script>
        <script src="{{ asset('js/mainBar.js') }}"></script>
        <?php include(app_path().'/includes/footer.php'); ?>
    </body>
    </html>

