<?php

namespace App\Http\Controllers;

use App\Models\CodeEtat;
use App\Models\Favoris;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class DashboardAdminController extends Controller
{
   

    public function deleteCodeEtat(Request $request, $idUtilisateur, $nomEtat){
        DB::table('CodeEtat')
        ->where('idUtilisateur', $idUtilisateur)
        ->where('NomEtat', $nomEtat)
        ->delete();
        return back();
    }

    
    public function updateCodeEtat(Request $request, $idUtilisateur)
    {
        $nomEtat = $request->code;
        $etat = $request->codeetat;

        DB::table('CodeEtat')
            ->where('idUtilisateur', $idUtilisateur)
            ->update(["NomEtat" => $nomEtat, "etat" => $etat]);
        return redirect("/dashboardadmin");
    }   

}
