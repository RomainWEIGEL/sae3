console.log("js lancé");

let divsFormation = document.querySelectorAll("div.unselectable.formation");
let divsParcours = document.querySelectorAll("div.unselectable.parcours");
let divCat = document.querySelectorAll("div.unselectable.cercleCat");
let divsLangue = document.querySelectorAll("div.unselectable.langueFilterDiv");
let divsThematique = document.querySelectorAll("div.unselectable.cercleThematique");
let divsAccueil = document.querySelectorAll("div.unselectable.divAcc");
let butFav = document.querySelectorAll("button.butFav");
let imageCounter = 2;
let nbFormation = 0;
let isCoched = true;

divsAccueil.forEach((div)=>{
    div.addEventListener("click", ()=> {
        document.location.href="/parcours/"+div.id;
    })
})
divsFormation.forEach((div)=> {
    let image = div.getElementsByClassName("formationImg")[0];
    //console.log(image);
    image.src = '../img/formation'+imageCounter.toString()+'.jpg';
    

    div.addEventListener("click", ()=> {

        if(idutilisateur != -1){
            // Obtenir la date et l'heure actuelles
            var dateActuelle = new Date();
            console.log(div.id)
            let donnees = {
                idutilisateur: idutilisateur,
                idformation: div.id,
                dateHeure: dateActuelle.getTime()
            }
            // URL de la route vers le contrôleur
            let url = '/historiqueformation';

            // Options de la requête
            let options = {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    //'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content') // Ajoutez le jeton CSRF si nécessaire
                },
                body: JSON.stringify(donnees)
            };

            // Envoyer la requête
            fetch(url, options)
                .then(response => response.json())
                .then(data => {
                    // Traitez la réponse ici
                    console.log(data);
                })
                .catch(error => {
                    // Gérez les erreurs ici
                    console.error('Erreur lors de la requête POST:', error);
                });
        }
        document.location.href="/formation/"+div.id;
    })
    div.addEventListener("mouseover", ()=> {
        div.style.backgroundColor = "#83c6d2";
    })
    div.addEventListener("mouseleave", ()=> {
        div.style.backgroundColor = "#baf1ffce";
    })

    if(nbFormation%2 == 0){
        imageCounter = 1;
    }
    else imageCounter++;
    nbFormation++

})

divsParcours.forEach((div)=> {
    let image = div.getElementsByClassName("formationImg")[0];
    //console.log(image);
    image.src = '../img/formation'+imageCounter.toString()+'.jpg';
    
    div.addEventListener("click", ()=> {
        document.location.href="/parcours/"+div.id;
    })
    div.addEventListener("mouseover", ()=> {
        div.style.backgroundColor = "#83c6d2";
    })
    div.addEventListener("mouseleave", ()=> {
        div.style.backgroundColor = "#baf1ffce";
    })
})

divCat.forEach((div)=> {
    div.addEventListener("click", ()=> {
        document.location.href="/categorie/"+div.id;
    })
})

divsThematique.forEach((div)=> {
    div.addEventListener("click", ()=> {
        document.location.href="/thematiques/"+div.id;
    })
})

let isCocheds = [];

divsLangue.forEach((div, index) => {
    isCocheds.push(true); 
    div.addEventListener("click", () => {
        divsFormation.forEach((divF) => {
            let langue = divF.getElementsByClassName("textBlock langue")[0];

            if (langue.id == div.id && isCocheds[index] === true) {
                divF.style.display = "none";
                div.style.backgroundColor = "white";
            } else if (langue.id == div.id && isCocheds[index] === false) {
                divF.style.display = "inline-block";
                div.style.backgroundColor = "#909090";
            }
        });

        isCocheds[index] = !isCocheds[index];
    });
});

butFav.forEach((butt) => {
    butt.addEventListener("click", () => {
        document.location.href="/connexioncompte"
    });
});

