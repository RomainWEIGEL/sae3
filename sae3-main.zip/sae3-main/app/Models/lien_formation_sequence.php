<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class lien_formation_sequence extends Model
{
    use HasFactory;
    protected $table = "lien_formation_sequence";
    protected $primaryKey = ["idutilisateur","idformation"];
    public $incrementing = false;
    public $timestamps = false;

    
    protected $fillable = [
        "idformation",
        "idsequence",
        "indexsequence"
    ];
}
