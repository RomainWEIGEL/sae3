<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
<title>SkillUpNow - Cate</title>
</head>
<body>
<?php include(app_path().'/includes/mainBar.php'); ?>
    <h1>Recherche de formations par catégorie</h1>
    <div id="catParent">
        @foreach ($categories as $categorie)
            <div class="unselectable cercleCat" id="{{$categorie->idcategorie}}">{{$categorie->nomcategorie}}</div>
        @endforeach
    </div>
    <?php include(app_path().'/includes/footer.php'); ?>
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
</body>
</html>