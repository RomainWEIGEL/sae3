<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>SkillUpNow</title>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?> 
    
    <h1>Catégorie : {{$categorie->nomcategorie}}</h1>
    <section>
        @foreach($langues as $idlangue => $nomlangue)
            <div id="{{$idlangue}}" class="unselectable langueFilterDiv">{{$nomlangue}}</div>
        @endforeach
    </section>
    <div class="forma">
    @foreach($categorie_formations as $categorie_formation)
        @if($categorie_formation->idcategorie == $categorie->idcategorie)
            @foreach ($formations as $formation)
                @if($formation->idformation == $categorie_formation->idformation)
                    <div class="unselectable formation" id="{{$formation->idformation}}">
                        <img class="formationImg" src="" alt="">
                        <div id="{{$formation->idlangue}}" class="textBlock langue">
                        @if($formation->prixformation == 0)
                            <h2 class="formationTitle">{{$formation->titreformation}} - Gratuite</h2> <br>
                        @else
                            <h2 class="formationTitle">{{$formation->titreformation}} <br> {{$formation->prixformation}} €</h2><br>
                        @endif
                        @if (strlen($formation->resumeformation) < 170)
                            <p class="textLigne">{{$formation->resumeformation}}</p>
                        @else
                            <p class="textLigne">{{substr($formation->resumeformation, 0, 170)}}...</p> 
                        @endif
                        <p class="textLigne interVenant"> <b>Intervenants </b> : {{$formation->intervenant->nomintervenant}}</p>
                        <div class="interVenantPopup "><p class="underline">{{$formation->intervenant->nomintervenant}} {{$formation->intervenant->prenomintervenant}}</p> {{$formation->intervenant->resumeintervenant}}</div>
                        <p><a href="/concepteur/{{$formation->idconcepteur}}"><b>Concepteur </b> : {{$formation->concepteur->nomecole}}</a></p>
                        <p class="textLigne"> <b>Niveau </b> : {{$formation->niveauformation->nomniveau}}</p>
                    </div>
                </div>
                @endif
            @endforeach
        @endif
    @endforeach
    </div>

    {{--     
    @foreach($categorie_formations as $categorie_formation)
        <div id="1">1</div>
    @endforeach

    @foreach ($formations as $formation)
        <div class="unselectable formation" id="{{$formation->idformation}}">
            <img class="formationImg" src="" alt="">
            <div class="textBlock">
            @foreach ($categories as $categorie)
                @if($categorie->idcategorie == $categorie_formation->idcategorie)
                    @if($formation->prixformation == 0)
                         <h2 class="formationTitle">{{$formation->titreformation}} - Gratuite</h2>
                    @else
                        <h2 class="formationTitle">{{$formation->titreformation}} - {{$formation->prixformation}} €</h2>
                    @endif
                @endif
            @endforeach   
            </div>
        </div>
    @endforeach
     --}}
     @if (Auth::check())
        {{Auth::user()->idutilisateur}}
        <script>let idutilisateur = {{Auth::user()->idutilisateur}};</script>
        <script src="{{ asset('js/main.js') }}"></script>    
    @else
        {{"pas connecté"}}
        <script>let idutilisateur = -1;</script>
        <script src="{{ asset('js/main.js') }}"></script>
    @endif
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
</body>
</html>
