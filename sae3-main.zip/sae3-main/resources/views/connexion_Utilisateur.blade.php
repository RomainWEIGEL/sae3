<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
<title>Création du compte</title>
</head>
<body>
<?php include(app_path().'/includes/mainBar.php'); ?>
    {{-- TEST FORMULAIRE ICI --}}
    <form action="{{ route("/login") }}" method="POST" class="form" id="connectForm">
        @csrf
        <h1 id="creationcomptetitre" class="signup"> Se Connecter </h1> 
        
        <div id="mailCreationCompte">
            <label for="mailutilisateur">E-mail :</label><br>
            <input type="email" id="mailutilisateur" name="mailutilisateur"  placeholder="exemple@domaine.com" maxlength="75" required class="form--input" value="{{ old("mailutilisateur") ? 'checked' : '' }}"><br>
        </div>
    
        <div id="mdpCreationCompte">
            <label for="passwd">Mot de passe :</label><br>
            <input type="password" id="passwd" name="passwd" required class="form--input" ><br>
        </div>
        <br>
            <div>{{ $errors->first('email') }}</div>
        <br>
        <input type="submit" value="Se connecter" class="form--submit">
        <p class="texteConnect" class="obligatoire form--input" >Vous ne possédez pas de compte? <a href="/creationcompte" class="lienPoliProtec">Créer un compte</a></p>
    </form>
{{-- FIN TEST FORMULAIRE --}}
<script src="{{ asset('js/mainBar.js') }}"></script>
<?php include(app_path().'/includes/footer.php'); ?>

</body>
</html>
