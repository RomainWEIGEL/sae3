<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pays;

class PaysController extends Controller
{
    public function getPays(){
        $pays = Pays::all();

        return view('pays', ["pays"=> $pays]);
    }

    public function showPays(Request $request, $codePays){
        $pays = Pays::findOrFail($codePays);

        return view("showPays", ["pays" => $pays]);
    }
        
    public function createPays(Request $request){
        $validatedData = $request->validate([
            'codePays' => ['required', 'string'],
            'nomPays' => ['required', 'string']
        ]);
        
        Pays::create($validatedData);
        
        return redirect("/");
    }
}
