let datesField = document.querySelectorAll(".datesFormationI");
let inputNbFormation = document.querySelector("input#nbformation");
let divLesSequences = document.querySelector("div#lesSequences");

let nbSequence = 0;
let lesSequences;
let hiddenField = document.createElement("input");

// List déroulante des intervenants dans proposer_formation
let checkList = document.getElementById('list1');
if(checkList != null){
    checkList.getElementsByClassName('anchor')[0].onclick = function(evt) {
        if (checkList.classList.contains('visible'))
          checkList.classList.remove('visible');
        else
          checkList.classList.add('visible');
      }
}

if(datesField != null){
    datesField.forEach((date)=> {
        date.valueAsDate = new Date(); 
    })
}

if(inputNbFormation != null){
    nbSequence = inputNbFormation.value;
    createSequenceForm();
    console.log("index_nbsequence : "+nbSequence);

    // Hidden Field
    hiddenField.type = "hidden";
    hiddenField.id = "nbsequence";
    hiddenField.name = "nbsequence";

    inputNbFormation.addEventListener("change", ()=>{
        if(inputNbFormation.value > nbSequence){
            nbSequence++;
            createSequenceForm();
            hiddenField.value = nbSequence;
            
        }else if(inputNbFormation.value < nbSequence){
            let sequences = document.getElementsByClassName("divSequenceFormation");
            if(sequences.length != 1){
                for (let index = 0; index < sequences.length; index++) {
                    if(index == sequences.length-1){
                        sequences[index].remove();
                        nbSequence--;
                        hiddenField.value = nbSequence;
                    }
                }
            }
        }
        console.log("index_nbsequence : "+nbSequence);
    })
}

function createSequenceForm(){
    let div = document.createElement("div");
    div.classList = "divSequenceFormation";
    div.id = nbSequence;

    formPart("nomSequenceFormationDiv", nbSequence+"_nomsequence", "Nom de la séquence :", div, "text", null, "Entrez le nom", "input");
    formPart("resumeSequenceFormationDiv", nbSequence+"_resumesequence", "Resume de la séquence :", div, "text", null, "Entrez le résumé", "textarea");
    formPart("dureeSequenceFormationDiv", nbSequence+"_dureesequence", "Durée de la ressource :", div, "number", 1, "Entrez la durée", "input");
    formPart("cheminSequenceFormationDiv", nbSequence+"_cheminressourcesequence", "Chemin de la ressource (http ou /ressources/) :", div, "text", "/ressources/", "Entrez le chemin", "input");
    div.appendChild(hiddenField);

    divLesSequences.appendChild(div);
}

function createInput(inputType, idPart, parent, baseInputValue, placeHolderInput, elementType){
    let input = document.createElement(elementType);
    input.type = inputType;
    input.id = idPart;
    input.name = idPart;
    input.placeholder = placeHolderInput;

    if(inputType == "number"){
        input.max = 8;
        input.min = 1;
        //input.onkeydown = "return disablekeys();";
    }
    if(baseInputValue != null){
        input.value = baseInputValue;
    }

    // Style
    input.style.width = "400px";
    input.style.borderRadius = "5px";

    parent.appendChild(input);
}

function createLabel(forId, parent, titre){
    let label = document.createElement("label");
    label.for = forId;
    label.innerText = titre;

    parent.appendChild(label);
}

function formPart(idDivPart, idPart, titreLabel, parent, inputType, baseInputValue, placeHolderInput, elementType){
    // Div
    let div = document.createElement("div");
    div.id = idDivPart;
    // Label
    createLabel(idPart, div, titreLabel);
    // Saut de ligne
    let br = document.createElement("br");
    div.appendChild(br);
    // Input
    createInput(inputType, idPart, div, baseInputValue, placeHolderInput, elementType);

    parent.appendChild(div);
}

