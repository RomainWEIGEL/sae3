<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleformation.css'); ?>">

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <title>Détails de la formation</title>
</head>
<body id="tableauformation">
<?php include(app_path().'/includes/mainBar.php'); ?>
    <div id="englobe">
        <div id="divGauche">
        
            <h1>{{$formation->titreformation}}</h1><br><br>
            <?php
            $estInscrit = false;
            if (Auth::guest()){
                $estConnecte = "false";
            }
            else{
                $estConnecte = "true";
                $totProgres = 0;
                $nbr = 0;
                foreach (Auth::user()->sequence as $seq){
                    foreach ($seq->formations as $form){
                        if($form->idformation == $formation->idformation){
                            if($seq->pivot->termine == "OUI"){
                                $nbr += 1;
                            }
                        }
                    }
                }
                foreach ($formation->sequence as $seq) {
                        $totProgres += 1;
                }
                if($totProgres != 0){
                    $totProgres = round(($nbr/$totProgres)*100,1);
                }
            }
            ?>
            @if($estConnecte == "true" && $totProgres != 0)
            <h1>{{$totProgres."%"}}<div class="review-bar" data-rating="{{$totProgres}}"></div></h1>

            @endif
            <h2 class="underline">Les séquences</h2>
            <form action="{{route("/saveProgressionFormation")}}" method="POST">
                @csrf
            <table >
                <thead id="tableauformationtitre">
                    <tr id="ligne">
                        <th>Ordre</th>
                        <th>Titre</th>
                        <th>Résumé</th>
                        <th>Durée (H)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $tot = 0;
                    $index = 1?>
                    @foreach ($formation->sequence as $seq)
                            {{-- {{$formation->pivot}} pour accéder à la table lien_formation_sequence pis index--}}
                            <?php $tot += $seq->dureesequence?>
                            <tr id="ligne">
                                <td>{{$index}}</td>
                                <td>{{$seq->nomsequence}}</td>
                                <td>{{$seq->resumesequence}}

                                        {{-- <img src="{{asset(substr($seq->cheminressourcesequence, 12))}}" alt="{{$seq->cheminressourcesequence}}"></summary> --}}
                                    <details close class="summaryHeader">
                                    {{--VIDEO YOUTUBE OU PDF OU HTML OU CONTENU--}}
                                    @if(substr($seq->cheminressourcesequence, 0, 8) == 'https://' || substr($seq->cheminressourcesequence, 0, 7) == 'http://')
                                        @if(substr($seq->cheminressourcesequence, 8, 8) == 'youtu.be')
                                        
                                            
                                            <summary class="unselectable">Prévisualisation du contenu</summary>
                                            <iframe width="420" height="315"
                                            src="https://www.youtube.com/embed/{{substr($seq->cheminressourcesequence, 17,strlen($seq->cheminressourcesequence)-17)}}">
                                            </iframe>
                                
                                        @else
                                            <p><a href="{{$seq->cheminressourcesequence}}">Lien de la ressource</a></p>
                                        @endif

                                    @elseif(substr($seq->cheminressourcesequence, 12, 3) == 'pdf')

                                        <summary class="unselectable summaryHeader">Prévisualisation du PDF</summary>
                                        <embed src="{{$seq->cheminressourcesequence}}" width="800" height="500" type="application/pdf"/>
                                            
                                    @elseif(substr($seq->cheminressourcesequence, 12, 4) == 'html')
                                        <p><a href="{{$seq->cheminressourcesequence}}" target="_blank">Prévisualisation de la page</a></p>
                                        {{--guide_entreprise_a4_web--}}
                                    @else
                                    {{-- <p>{{substr($seq->cheminressourcesequence, 8)}}</p> --}}

                                        <summary class="unselectable">Prévisualisation du contenu</summary>
                                        <img src="{{$seq->cheminressourcesequence}}" alt="{{$seq->cheminressourcesequence}}"> {{-- https://picsum.photos/200/300 --}}

                                    @endif
                                    
                                    <br>

                                    @if ($estConnecte == "true")
                                        
                                        <?php 
                                            if (App\Models\InscriptionFormation::where('idformation', $formation->idformation)
                                                    ->where('idutilisateur', Auth::user()->idutilisateur)
                                                    ->first()){
                                                    $estinscrit = true;
                                                // CHECKBOXES
                                                //-----------------------------------------------------------------
                                                $progresSequence = App\Models\ProgresSequence::where('idsequence', $seq->idsequence)
                                                    ->where('idutilisateur', Auth::user()->idutilisateur)
                                                    ->first();
                                                
                                                // CHECKBOXES HTML
                                                    echo '<input id="ckFinit'.$seq->idsequence.'" type="checkbox" name="sequence_ids[]" value="' . $seq->idsequence . '"';
                                                // Vérifier si la séquence est marquée comme terminée pour l'utilisateur
                                                if ($progresSequence && $progresSequence->termine == 'OUI') {
                                                    echo ' checked';
                                                }
                                                echo '>';
                                                
                                                // le label
                                                echo '<label for="ckFinit'.$seq->idsequence.'"> J\'ai terminé </label>';

                                                $date = App\Models\Date::create([]);
                                                $idDate = App\Models\Date::where('iddate', $date->iddate)->first()->iddate;

                                                // Check if the progress sequence doesn't exist
                                                if (!$progresSequence) {
                                                    $progresSequence = new App\Models\ProgresSequence([
                                                        'idutilisation' => Auth::user()->idutilisateur,
                                                        'idsequence' => $seq->idsequence,
                                                        'termine' => 'NON',
                                                        'datefin' => $idDate // Save the date in the desired format
                                                    ]);
                                                }

                                                // la date
                                                if ($progresSequence->datefin != null) {                                                 
                                                    $date=App\Models\Date::where('iddate', $progresSequence->datefin)->first();
                                                    $date = date('Y-m-d', $progresSequence->Date->date);
                                                }
                                                else {
                                                    $date = today();
                                                }
                                                echo '<input type=date name="dateSeqs[]" id=dateSeqs'.$seq->idsequence.' value="'.$date;
                                                echo '">';
                                            }
                                            ?>
                                            
                                    @endif
                                    </details>
                                </td>
                                <td>{{$seq->dureesequence}}</td>
                            </tr>
                        <?php $index += 1?>
                    @endforeach
                    <tr id="ligne">
                        <td>Total</td>
                        <td></td>
                        <td>
                        </td>
                        <td>{{$tot}}</td>
                    </tr>
                </tbody>
            </table>

            <input type="hidden" name="idformation" value="{{ $formation->idformation }}">
            
            @if (!Auth::guest() && App\Models\InscriptionFormation::where('idutilisateur', Auth::user()->idutilisateur)
            ->where('idformation', $formation->idformation)
            ->first())
                <button type="submit" class="styleBouton">Enregistrer</button>
            @endif
            </form>

            <div style="height:20px"></div>
            <h2 class="underline">Les avis</h2>
            <?php $datedelavis = 0; $nomu = ""; $moy = [0,0,0,0]?>
            @foreach ($formation->avis as $avi)
                <?php $moy[0] += $avi->notecontenu;
                $moy[1] += $avi->noteplateforme;
                $moy[2] += $avi->noteanimation;
                $moy[3] += 1;?>
            @endforeach
            @if($moy[3] !=0)
                <?php $moy[0] = round($moy[0]/$moy[3],1);
                $moy[1] = round($moy[1]/$moy[3],1);
                $moy[2] = round($moy[2]/$moy[3],1);
                $moy[3] = round(((($moy[0]+$moy[1]+$moy[2])/3)/5)*100,1)?>
            @endif
            <div id="graph"><canvas id="myChart" data-contenu="{{$moy[0]}}" data-plateforme="{{$moy[1]}}" data-animation="{{$moy[2]}}"></canvas></div>
            <table>
                <thead id="tableauformationtitre">
                    <tr id="ligne">
                        <th>Nom utilisateur</th>
                        <th>Avis</th>
                        <th>Note contenu</th>
                        <th>Note plateforme</th>
                        <th>Note animation</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($formation->avis as $avi)
                        <tr id="ligne">
                            @if($avi->utilisateur->nomutilisateur==null || $avi->utilisateur->prenomutilisateur == null)
                                @php
                                    $parts = explode('@', $avi->utilisateur->mailutilisateur);
                                    $firstPart = $parts[0];
                                @endphp
                                <td>{{$firstPart}}</td>
                            @else
                                <td>{{$avi->utilisateur->nomutilisateur." ".$avi->utilisateur->prenomutilisateur}}</td>
                            @endif
                            <td>{{$avi->texteavis}}</td>
                            <td>{{$avi->notecontenu}}</td>
                            <td>{{$avi->noteplateforme}}</td>
                            <td>{{$avi->noteanimation}}</td>
                            <td>{{ \Carbon\Carbon::parse($avi->dateAvis->date)->format('d/m/Y') }}</td>
                        </tr>
                    @endforeach
                    <tr>
                        <td></td>
                        <td style="text-align: end;">Moyenne des avis</td>
                        <td>{{$moy[0]}}</td>
                        <td>{{$moy[1], 1}}</td>
                        <td>{{$moy[2]}}</td>
                        <td>
                            <div class="review-bar" data-rating="{{$moy[3]}}"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div id="divDroite">

            <div>
                <img src="/img/formation2.jpg" class="imgDivDroite">
                <div class="baseDiv">
                    <p>{{$formation->resumeformation}}</p> <br>
                </div>
                <div class="baseDiv">
                    <p>Date de début : {{ \Carbon\Carbon::parse($formation->dateDebutFormation->date)->format('d/m/Y') }}</p> 
                </div>
                <div class="baseDiv">
                    <p>Date de fin : {{ \Carbon\Carbon::parse($formation->dateFinFormation->date)->format('d/m/Y') }}</p>
                </div>  
                <div class="baseDiv">
                    @if ($formation->prixformation == 0)
                        <p>Montant de la formation: Gratuite</p>
                    @else
                        <p>Montant de la formation: {{$formation->prixformation}}€</p>
                    @endif
                </div>
                <div>  
                    <p class="textLigne interVenant"> <b>Intervenants </b> : {{$formation->intervenant->nomintervenant}}</p>
                    <div class="interVenantPopup baseDiv"><p class="underline">{{$formation->intervenant->nomintervenant}} {{$formation->intervenant->prenomintervenant}}</p> {{$formation->intervenant->resumeintervenant}}</div>
                </div>
                <div class="baseDiv">
                    <p><a href="/concepteur/{{$formation->idconcepteur}}">Concepteur</a></p>
                </div>
            </div>
            <div class="disForm">
                    {{-- AJOUT AUX FAVORIS --}}
                    @if ($estConnecte == "false")
                        <button type=submit name="fav" class="styleBouton butFav"><img src="{{ asset('img/favoris.png') }}" style="width:20px;"> Ajouter aux favoris </button>                  
                        <button type=submit name="insc" class="styleBouton butFav" ><img src="{{ asset('img/favoris.png') }}" style="width:20px;"> S'inscrire </button>
                    @elseif ($estConnecte == "true")
                        <form action="{{ route("/favoris") }}" method="POST" >
                            @csrf
                            @if (!App\Models\Favoris::where('idutilisateur', Auth::user()->idutilisateur)
                            ->where('idformation', $formation->idformation)
                            ->first())
                                <button type=submit id="fav" name="fav" value={{(int)($formation->idformation)}} class="styleBouton"><img src="{{ asset('img/favoris.png') }}" style="width:20px;"> Ajouter aux favoris </button>
                            @else
                                <button type=submit id="favdis" name="favdis" disabled value={{(int)($formation->idformation)}} class="styleBouton"><img src="{{ asset('img/FavorisLike.png') }}" style="width:20px;"> Formation favoris </button>
                            @endif
                        </form>
                        <form action="{{ route("/inscriptionformation") }}" method="POST" class="disForm">
                            @csrf
                            @if (!App\Models\InscriptionFormation::where('idutilisateur', Auth::user()->idutilisateur)
                                                                    ->where('idformation', $formation->idformation)
                                                                    ->first())
                                <button type=submit id="insc" name="insc" class="styleBouton" value={{(int)($formation->idformation)}} ><img src="{{ asset('img/favoris.png') }}" style="width:20px;"> S'inscrire </button>
                            @else
                                <button type=submit id="inscdis" name="inscdis" disabled value={{(int)($formation->idformation)}} class="styleBouton"><img src="{{ asset('img/FavorisLike.png') }}" style="width:20px;"> Inscrit </button>
                            @endif
                        </form>
                    @endif
            </div>
        </div>
    </div>                      
    <script src="{{ asset('js/main.js') }}"></script>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    <script src="{{ asset('js/review.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
    <?php exit; ?>
</body>
</html>
