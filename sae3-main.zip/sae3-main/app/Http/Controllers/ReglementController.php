<?php

namespace App\Http\Controllers;

use App\Models\Date;
use App\Models\Reglement;
use DateTime;
use DateTimeZone;
use Illuminate\Http\Client\Request as ClientRequest;
use Illuminate\Http\Request;

class ReglementController extends Controller
{
    public function createReglement($montantreglement) {
        // DATE REGLEMENT
        $date = Date::create([]);
        $idDate = Date::where('iddate', $date->iddate)->first()->iddate;
    
        // REFERENCEREGLEMENT
        $latestReglement = Reglement::where('referencereglement', 'like', 'PAY-REF-%')
                                ->orderByRaw("CAST(SUBSTRING(referencereglement FROM 9) AS INTEGER) DESC")
                                ->first()->referencereglement;


        
        if ($latestReglement != null) {
            $str = $latestReglement;
            $parts = explode('-', $str);
            $number = (int)end($parts); // This retrieves the last element of the array, which is '101'
            
            $nextNumber = $number + 1;
            $nextReference = 'PAY-REF-' . $nextNumber;
            
        } else {
            $nextReference = 'PAY-REF-1';
        }
    
        $reference = $nextReference;
    
        
        $reglement = Reglement::create([
            'referencereglement' => $reference,
            'datereglement' => $idDate,
            'montantreglement' => $montantreglement
        ]);
        
        // ON RENVOIE LA REFERENCE DU REGLEMENT
        return $reference;
    }
}
