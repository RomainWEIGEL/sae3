<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>SkillUpNow</title>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>
    
    <h1>Recherche de parcours par thématique</h1>
    <div id="thematiqueParent">
        @foreach ($thematiques as $thematique)
            <div class="unselectable cercleThematique"id="{{$thematique->iddomaine}}">{{$thematique->nomdomaine}}</div>
        @endforeach
    </div>

    <?php include(app_path().'/includes/footer.php'); ?>
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
</body>
</html>
