<?php

namespace App\Http\Controllers;

use App\Models\Categorie;
use App\Models\Formation;

use Illuminate\Http\Request;

class CategorieController extends Controller
{
    public function getCategorie(){
        /**
         * Summary.
         * Récupère toutes les formations, toutes les catégories et renvoit la vue categorie avec ce qui a été récupéré.
         */
        $categories = Categorie::all();
        $formations = Formation::all();
        return view('categorie', ["categories"=> $categories, "formations"=>$formations]);
    }
}
