
<div class="mainBar">
    <img src="<?php

use Illuminate\Support\Facades\Auth;

 echo asset('img/logo.png'); ?>" alt="logo" id="logo">
    <!-- <h1 id="mainBarFormations" class="unselectable ongletMainBar">&nbsp;&nbsp;&nbsp;&nbsp;FORMATIONS</h1> -->
    <h1 id="mainBarCategories" class="unselectable ongletMainBar">&nbsp;&nbsp;&nbsp;&nbsp;FORMATIONS</h1>
    <p id = "parformations" class="unselectable">par <b class="dore unselectable">catégorie</b></p>
    <img id = "imgBarCategories" src = "<?php echo asset('img/teaching.png'); ?>"></img>
    <h1 id="mainBarThematiques" class="unselectable ongletMainBar">&nbsp;&nbsp;&nbsp;&nbsp;PARCOURS</img></h1>
    <p id="parparcours" class="unselectable">par <b class="dore unselectable">thématique</b></p>
    <img id="imgBarThematiques" src = "<?php echo asset('img/path.png'); ?>">

    <div id="seConnecterDiv">
        <img src="<?php echo asset('img/utilisateur.png'); ?>" id="compteImg">
        
        <?php 
        if(!Auth::guest()) // si connecte
        {
            if(Auth::user()->CodeEtat != null){
                if(strtolower(Auth::user()->CodeEtat->NomEtat == "admin"))                      //si admin
                {
                    echo("<p id=\"textCreateUser\" class=\"baseP unselectable\">admin</p>");
                }elseif(strtolower(Auth::user()->CodeEtat->NomEtat == "concepteur"))            // si concepteur
                {
                    echo("<p id=\"textCreateUser\" class=\"baseP unselectable\">concepteur</p>"); // b@b.fr - aaaaaaaaaa10à
                }
            }elseif(Auth::user()->CodeEtat == null || Auth::user()->CodeEtat == "utilisateur"){                                   // si utilisateur
                if(Auth::user()->nomutilisateur == null || Auth::user()->prenomutilisateur == null){
                    $parts = explode('@', Auth::user()->mailutilisateur);
                    $firstPart = $parts[0];
                    echo("<p id=\"textCreateUser\">".$firstPart."</p>");
                }
                else {
                    echo("<p id=\"textCreateUser\">".Auth::user()->nomutilisateur." ".Auth::user()->prenomutilisateur."</p>");
                }   
            }
        }else {
            echo("<p id=\"textCreateUser\" class=\"baseP unselectable\">Se Connecter</p>");
        }   
        ?>
    </div>
    <?php
    if(!Auth::guest() && Auth::user()->CodeEtat != null && strtolower(Auth::user()->CodeEtat->NomEtat == "concepteur")){
        echo"<div id='divBtnMenuConcepteur'><p class='unselectable' style='line-height: 80px;color:white;'>Proposer une formation</p></div>";
    }
    ?>
</div>