<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
<title>SkillUpNow</title>
    <!-- Les liens vers les bibliothèques jQuery et le fichier JavaScript de votre application -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Vérification de la présence du message de succès
            @if(session('success'))
                alert('{{ session('success') }}');
                document.location.href="{{URL::to('/connexioncompte')}}";
            @elseif(session('succesformation'))
                alert('{{ session('succesformation') }}');
            @endif
        });
    </script>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>
    <div id="contenuAcc">
        <img src="/img/header.jpg" class="accImage unselectable">
        <div id="divAlaUne">
            <p class="pALaUne">A la une</p>
            <div class="divAcc unselectable divAcc1" id="9">
                <img src="img/formation1.jpg" class="imagesAcc" >
                <p class="pAcc">
                    @foreach ($parcours as $parcour)
                        @if($parcour->idparcours == '9')
                        {{$parcour->titreparcours}}
                        @endif           
                        
                    @endforeach            
                </p>
            </div> 
            <div class="divAcc unselectable divAcc2" id="1">
                <img src="img/formation1.jpg" class="imagesAcc">
                <p class="pAcc">
                    @foreach ($parcours as $parcour)
                        @if($parcour->idparcours == '1')
                        {{$parcour->titreparcours}}
                        @endif           
                        
                    @endforeach
                </p>
            </div> 
            <div class="divAcc unselectable divAcc3" id="6">
                <img src="img/formation1.jpg" class="imagesAcc">
                <p class="pAcc">
                    @foreach ($parcours as $parcour)
                        @if($parcour->idparcours == '6')
                        {{$parcour->titreparcours}}
                        @endif           
                        
                    @endforeach
                </p>
            </div>
    </div> 
    </div>
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
</body>
</html>