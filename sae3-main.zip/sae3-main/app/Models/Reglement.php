<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Reglement extends Model
{
    use HasFactory;
    protected $table = "reglement";
    protected $primaryKey = "referencereglement";
    public $incrementing = false;
    public $timestamps = false;

    
    protected $fillable = [
        "referencereglement",
        "datereglement",
        "montantreglement"
    ];

    public function InscriptionFormation(){
        return $this->belongsTo(InscriptionFormation::class, 'referencereglement', 'referencereglement');
    }

    public function date(){
        return $this->belongsTo(Date::class, 'iddate', 'datereglement');
    }

    protected $casts = [
        'montantreglement' => 'float'
    ];
}
