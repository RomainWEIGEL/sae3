<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo asset('styleparcours.css'); ?>">
    <title>SkillUpNow - Proposition</title>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>

    <!-- Chargement des bibliothèques javascript jquery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
    <form action="/proposer_formation" method="POST" class="form" id="creationFormationform">
        <h1 id="creationFormationtitre">Proposez-nous votre formation</h1>
    
        @csrf
     
        {{-- TODO : idformation --}}
        {{-- TODO : probleme acces avec url --}}

        {{-- DOMAINE --}}
        <div id="domaineFormation">
            <label for="iddomaine">Domaine d'apprentissage :</label>
            <input id="iddomaine" name="iddomaine" list="etats" value="{{ old('iddomaine') }}">
            <datalist id="etats">
                @foreach($domaines as $dom)
                    <option value="{{$dom->iddomaine}}">{{$dom->nomdomaine}}</option>
                @endforeach
            </datalist>

            {{-- Suppression auto-complétion --}}
            <script>
                $('input#iddomaine').on('click', function() {
                    $(this).val('');
                });
            </script>
        </div>
        @error('iddomaine')
         <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- CATEGORIE --}}
        <div id="categorieFormation">
            <label for="idcategorie">Catégorie :</label>
            <input id="idcategorie" name="idcategorie" list="etatsC" value="{{ old('idcategorie') }}">
            <datalist id="etatsC">
                @foreach($categories as $cat)
                    <option value="{{$cat->idcategorie}}">{{$cat->nomcategorie}}</option>
                @endforeach
            </datalist>

            {{-- Suppression auto-complétion --}}
            <script>
                $('input#idcategorie').on('click', function() {
                    $(this).val('');
                });
            </script>
        </div>
        @error('idcategorie')
         <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- SEQUENCE 
        <div id="list1" class="dropdown-check-list" tabindex="100">
            <span class="anchor">Sélectionner des séquences</span>
            <ul class="items">
                @foreach ($intervenants as $inter)
                    <li><input id="idintervenant" name="idintervenant" type="checkbox" />{{$inter->nomintervenant}} {{$inter->prenomintervenant}}</li>
                @endforeach
            </ul>
        </div> --}}

        {{-- INTERVENANT --}}
        <div id="intervenantFormation">
            <label for="idintervenant">Intervenant :</label>
            <input id="idintervenant" name="idintervenant" list="intervenantE" value="{{ old('idintervenant') }}">
            <datalist id="intervenantE">
                @foreach($intervenants as $l)
                    <option value="{{$l->idintervenant}}">{{$l->nomintervenant}} {{$l->prenomintervenant}}</option>
                @endforeach
            </datalist>

            {{-- Suppression auto-complétion --}}
            <script>
                $('input#idintervenant').on('click', function() {
                    $(this).val('');
                });
            </script>
        </div>
        @error('idintervenant')
         <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- CHAMP CACHÉ IDCONCEPTEUR --}}
        <?php
            $concepteurID = (Auth::user()->Concepteur)[0]->idconcepteur;
            //dd($concepteurID);
            echo "<input type='hidden' id='idconcepteur' name='idconcepteur' value='{$concepteurID}' />";
        ?>

        {{-- TITRE FORMATION --}}
        <div id="titreFormation">
            <label for="titreformation">Titre de la formation :</label><br>
            <input type="text" id="titreformation" name="titreformation" autofocus maxlength="100" minlength="5" class="form--input" placeholder="Entrez le titre de la formation" value="{{ old('titreformation') }}"><br>
        </div>
        @error('titreformation')
            <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- RESUME FORMATION --}}
        <div id="resumeFormation">
            <label for="resumeformation">Résumé de la formation :</label><br>
            <input type="text" id="resumeformation" name="resumeformation" autofocus maxlength="500" minlength="5" class="form--input" placeholder="Entrez le résumé de la formation" value="{{ old('resumeformation') }}"><br>
        </div>
        @error('resumeformation')
            <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- DATE DEBUT & FIN FORMATION --}}
        <h3>Dates de la formation :</h3>
        <div id="datesFormation">
            <fieldset style="display: inline-block;">
                    <label for="datedebutformation" style="display: inline-block"></label>
                    <input id="datedebutformation" class="datesFormationI" style="display: inline-block" name="datedebutformation" type="date"/>
                    <p style="display: inline-block">➔</p>
                    <label for="datefinformation" style="display: inline-block"></label>
                    <input id="datefinformation" class="datesFormationI" style="display: inline-block" name="datefinformation" type="date"/>
              </fieldset>
        </div>

        {{-- LANGUE --}}
        <div id="langueFormation">
            <label for="idlangue">Langue :</label>
            <input id="idlangue" name="idlangue" list="languesE" value="{{ old('idlangue') }}">
            <datalist id="languesE">
                @foreach($langues as $l)
                    <option value="{{$l->idlangue}}">{{$l->nomlangue}}</option>
                @endforeach
            </datalist>

            {{-- Suppression auto-complétion --}}
            <script>
                $('input#idlangue').on('click', function() {
                    $(this).val('');
                });
            </script>
        </div>
        @error('idlangue')
            <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- NIVEAU --}}
        <div id="niveauFormation">
            <label for="idniveau">Niveau :</label>
            <input id="idniveau" name="idniveau" list="niveauxE" value="{{ old('idniveau') }}">
            <datalist id="niveauxE">
                @foreach($niveaux as $l)
                    <option value="{{$l->idniveau}}">{{$l->nomniveau}}</option>
                @endforeach
            </datalist>

            {{-- Suppression auto-complétion --}}
            <script>
                $('input#idniveau').on('click', function() {
                    $(this).val('');
                });
            </script>
        </div>
        @error('idniveau')
            <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- PRIX FORMATION --}}
        <div id="prixFormation">
            <label for="prixformation">Prix de la formation :</label><br>
            <input type="number" id="prixformation" name="prixformation" min="0" max="999" autofocus maxlength="3" minlength="1" class="form--input" placeholder="Entrez le prix de la formation" value="{{ old('prixformation') }}"><br>
        </div>
        @error('prixformation')
            <div style="color:red;">{{ $message }}</div>
        @enderror

        {{-- SEQUENCES --}}
        <div id="choixNbFormation">
            <label for="nbformation">Nombre de séquences :</label><br>
            <input type="number" id="nbformation" name="nbformation" min="1" max="5" autofocus maxlength="1" minlength="1" class="form--input" onkeydown="return false" placeholder="Entrez le nombre de séquence" value="1"><br>
        </div>

        <h3>Les sequences :</h3>
        <div id="lesSequences"></div>

        @error('nbformation')
            <div style="color:red;">{{ $message }}</div>
        @enderror
        
        <input type="submit" value="Créer" class="form--submit">
    </form>

    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <script src="{{ asset('js/proposer_parcours.js') }}"></script>
</body>
    <?php include(app_path().'/includes/footer.php'); ?>
</html>