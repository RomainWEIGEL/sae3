<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Auth\Authenticatable as AuthenticableTrait;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;


    protected $table = "utilisateur";
    protected $primaryKey = "idutilisateur";
    public $timestamps = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'nomutilisateur',
        'prenomutilisateur',
        'mailutilisateur',
        'mdpu',
        'codecommune'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'mdpu',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'codecommune' => 'integer',
        'mailutilisateur' => 'string',
        'mdpu' => 'hashed',
    ];

    public function getAuthPassword() {
        return $this->mdpu;
    }

    public function codecommuneL()
    {
        return $this->belongsTo(Ville::class, 'codecommune', 'codecommune');
    }

    public function Favoris(){
        return $this->hasMany(Favoris::class, 'idutilisateur', 'idutilisateur');
    }

    public function Formation(){
         return $this->belongsToMany(Formation::class, 'inscription_formation', 'idutilisateur', 'idformation')->withPivot('referencereglement', 'dateinscriptionformation', 'idinscriptionformation');
     }
     public function ParcoursFavoris(){
        return $this->hasMany(FavorisParcours::class, 'idutilisateur', 'idutilisateur');
    }

     public function Sequence(){
        return $this->belongsToMany(Sequence::class, 'progres_sequence', 'idutilisateur', 'idsequence')->withPivot('termine','idsequence');
    }
    public function ProgresSequence(){
        return $this->hasMany(ProgresSequence::class, 'idutilisateur', 'idutilisateur');
    }

    public function Competences()
    {
        return $this->belongsToMany(Competence::class, 'competence_utilisateur', 'idutilisateur', 'idcompetence');
    }
    public function CodeEtat()
    {
        return $this->belongsTo(CodeEtat::class, 'idutilisateur', 'idUtilisateur');
    }
    public function Concepteur()
    {
        return $this->belongsToMany(Concepteur::class, 'UtilisateurConcepteur', 'idUtilisateur', 'idConcepteur');
    }
}
