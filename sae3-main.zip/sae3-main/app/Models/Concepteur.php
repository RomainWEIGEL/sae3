<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Concepteur extends Model
{
    use HasFactory;
    protected $table = "concepteur";
    protected $primaryKey = "idconcepteur";
    public $timestamps = false;

    
    protected $fillable = [
        "nomecole",
        "resumeconcepteur"
    ];
    // Relation avec les formations
    public function formations()
    {
        return $this->hasMany(Formation::class, 'idconcepteur', 'idconcepteur');
    }
}
