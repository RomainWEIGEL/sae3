<?php

namespace App\Http\Controllers;

use App\Models\Ville;
use Illuminate\Http\Request;

class VilleController extends Controller
{
    public function getVilles(){
        $villes = Ville::all();

        return view('creation_Utilisateur', ["villes"=> $villes]);
    }

    public function showVille(Request $request, $codeINSEE){
        $ville = Ville::findOrFail($codeINSEE);

        return view("villes", ["ville" => $ville]);
    }
        
    public function createVille(Request $request){
        $validatedData = $request->validate([
            'codeINSEE' => ['required', 'string'],
            'codepays' => ['required', 'string'],
            'nomville' => ['required', 'string'],
            'codePostal' => ['required', 'string']

        ]);
        
        Ville::create($validatedData);
        
        return redirect("/");
    }
}
