<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Favoris extends Model
{
    use HasFactory;
    protected $table = "favoris";
    protected $primaryKey = ["idutilisateur","idformation"];
    public $incrementing = false;
    public $timestamps = false;

    
    protected $fillable = [
        "idutilisateur",
        "idformation"
    ];

    public function utilisateur()
    {
        return $this->belongsTo(User::class, 'idutilisateur', 'idutilisateur');
    }

    public function formation()
    {
        return $this->belongsTo(Formation::class, 'idformation', 'idformation');
    }
}
