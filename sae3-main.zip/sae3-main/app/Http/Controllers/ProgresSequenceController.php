<?php

namespace App\Http\Controllers;

use App\Models\Date;
use App\Models\lien_formation_sequence;
use App\Models\ProgresSequence;
use App\Models\Sequence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProgresSequenceController extends Controller
{

    public function updateProgres(Request $request)
    {
        $sequenceIds = $request->input('sequence_ids');
        $dateSeq = $request->input('dateSeqs');

        $formationId = (int)$request->input('idformation');
        $sequencesFormation = lien_formation_sequence::where('idformation', $formationId)
                                                    ->pluck('idsequence')
                                                    ->toArray();

        $i = 0;
        foreach ($sequencesFormation as $sequenceIdDansFormation) {
            $progressRecord = ProgresSequence::where('idsequence', $sequenceIdDansFormation)
                                            ->where('idutilisateur', Auth::user()->idutilisateur)
                                            ->first();

       
            // DATE
            if($dateSeq[$i] != null){
                $date = Date::create(['date'=>$dateSeq[$i]]);
                $idDate = Date::where('iddate', $date->iddate)->first()->iddate;
                
                
            }

            // TERMINE (OUI OU NON)
            if ($progressRecord != null) {
                // les séquences finies dans la liste de toutes les séquences
                if ($sequenceIds != null){
                    $progressRecord->termine=in_array($sequenceIdDansFormation, $sequenceIds) ? 'OUI' : 'NON';}
                else{
                    $progressRecord->termine='NON';
                }
                
                $progressRecord->datefin=$idDate;
                // METTRE A JOUR CAR IL EXISTE
                ProgresSequence::where('idsequence', $sequenceIdDansFormation)
                                ->where('idutilisateur', Auth::user()->idutilisateur)
                                ->update($progressRecord->toArray());

            } else {
                // CREER UN NOUVEL ENREGISTREMENT CAR IL N'EXISTE PAS
                if ($sequenceIds != null){
                    $termineVar = in_array($sequenceIdDansFormation, $sequenceIds) ? 'OUI' : 'NON';} else {
                    $termineVar = 'NON';
                    }
                ProgresSequence::create([
                    'idsequence' => $sequenceIdDansFormation,
                    'idutilisateur' => Auth::user()->idutilisateur,
                    'termine' => $termineVar,
                    'datefin' => $idDate
                ]);
            }
            $i++;
        }
        
        return back();
    }
}

