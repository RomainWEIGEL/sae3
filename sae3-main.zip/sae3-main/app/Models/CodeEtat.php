<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CodeEtat extends Model
{
    use HasFactory;
    protected $table = "CodeEtat";
    protected $primaryKey = "idUtilisateur";
    public $incrementing = false;
    public $timestamps = false;

    
    protected $fillable = [
        "NomEtat",
        "etat"
    ];

    public function utilisateur()
    {
        return $this->belongsTo(User::class, 'idUtilisateur', 'idutilisateur');
    }

      public function getCodeEtats(){
        $codeEtats = CodeEtat::All();
        $villes = Ville::all();
        $user = User::all();
        
        return view('/dashboard_Admin', ["villes"=> $villes, "user" => $user, "codeEtats" => $codeEtats]);
        
    }

    public function User()
    {
        return $this->belongsTo(User::class, 'idUtilisateur', 'idutilisateur');
    }


    
}
