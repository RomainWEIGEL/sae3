<?php

namespace App\Http\Controllers;

use App\Http\Controllers\ReglementController;
use App\Models\Date;
use App\Models\Formation;
use App\Models\InscriptionFormation;
use App\Models\Reglement;
use DateTime;
use DateTimeZone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class InscriptionformationController extends Controller
{
    public function createInscription(Request $request) {
        // DATE INSCRIPTION FORMATION
        $date = Date::create([]);
        $idDate = Date::where('iddate', $date->iddate)->first();

        // FORMATION
        $idformation = (int)$request->insc;
        $prixformation = Formation::findOrFail($idformation)->prixformation;

        // REFERENCEREGLEMENT
        $referenceReglement = new ReglementController();
        $idReferenceReglement = $referenceReglement->createReglement($prixformation);
        
        // Vérifier si ce favori existe déjà pour cet utilisateur et cette formation
        $existingInscription = InscriptionFormation::where('idutilisateur', Auth::user()->idutilisateur)
            ->where('idformation', $idformation)
            ->first();
    
        if (!$existingInscription) {
            // Si le favori n'existe pas, créez-le
            InscriptionFormation::create([
                'idutilisateur' => Auth::user()->idutilisateur,
                'idformation' => $idformation,
                'referencereglement' => $idReferenceReglement,
                'dateinscriptionformation'=> $idDate->iddate
            ]);
        }
    
        return back();
    }
}
