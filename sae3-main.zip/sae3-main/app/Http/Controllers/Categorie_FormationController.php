<?php

namespace App\Http\Controllers;

use App\Models\Categorie_Formation;
use App\Models\Categorie;
use App\Models\Formation;
use App\Models\Langue;

use Illuminate\Http\Request;

class Categorie_FormationController extends Controller
{
    /*
    public function getCategorie_Formation(){
        $categorie_formations = Categorie_Formation::all();
        $categories = Categorie::all();
        $formations = Formation::all();
        return view('show_formation_par_categorie', ["categorie_formations"=>$categorie_formations, "categories"=> $categories, "formations"=>$formations]);
    }
    */
    //, "categories" =>$categories, "formations"=> $formations
    
    /**
     * 
     * Fonction permettant d'afficher une catégorie de formation précise.
     * 
     * Prend en paramètre l'id de la catégorie à afficher et la requête. Ensuite, procède à un potentiel filtre par langue pour n'afficher que les formations d'une 
     * certaine langue et retourne la vue "formation par catégorie".
     */
    public function showCategorie_Formation(Request $request, $id){


        /*
        $categories_formation = Categorie_Formation::all();
        $id_formations = [];
        foreach ($categories_formation as $categorie_form) {
            if ($categorie_form->idcategorie == $id) {
                array_push($id_formations, $categorie_form->idformation);
            }
        }*/

        $categories_formation = Categorie_Formation::all();
        $categorie = Categorie::FindOrFail($id);
        $formations = Formation::all();

        $langues = Langue::all();
        $languesIds = array();
        $languesAssoc = array();

        foreach ($categories_formation as $categorie_formation) {
            if ($categorie_formation->idcategorie == $categorie->idcategorie) {
                foreach ($formations as $formation) {
                    if ($formation->idformation == $categorie_formation->idformation) {
                        array_push($languesIds, $formation->idlangue);
                    }
                }
            }
        }

        foreach ($langues as $langue) {
            if (in_array($langue->idlangue, $languesIds)) {
                // Utiliser l'id de la langue comme clé dans le tableau associatif
                $languesAssoc[$langue->idlangue] = $langue->nomlangue;
            }
        }

        return view("show_formations_par_categorie", ["categorie_formations" => $categories_formation, "categorie" =>$categorie, "formations"=> $formations, "langues"=>$languesAssoc]);
    }
    
}
