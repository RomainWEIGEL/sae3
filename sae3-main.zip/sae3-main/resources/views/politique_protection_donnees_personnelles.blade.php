<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
<?php include(app_path().'/includes/mainBar.php'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo asset('politiqueProtectionDonnees.css'); ?>">
<div class="poliPro">
    
    <h1>I – DISPOSITIONS GÉNÉRALES</h1>
    <div>Les dispositions qui suivent concernent tous les traitements de données personnelles effectués par le responsable du traitement, sauf mention contraire dans les dispositions spécifiques.
    </div><h2>1.	CONFORMITÉ AU RGPD ET À LA LOI FRANÇAISE</h2>
    <div>Le responsable du traitement (Monsieur El Hakouni Mohamed) déclare qu’il effectue des traitements de données personnelles conformément au règlement (UE) 2016/679 du Parlement européen et du Conseil du 27 avril 2016; relatif à la protection des personnes physiques à l’égard du traitement des données à caractère personnel et à la libre circulation de ces données (ci-après désigné le RGPD) et à loi française n° 78-17 du 6 janvier 1978 relative à l’informatique, aux fichiers et aux libertés, ainsi qu’aux autres dispositions applicables en France aux traitements de données personnelles.
    </div>
    <br>
    
    <h2>2.	RESPONSABLE DU TRAITEMENT ET AUTRES INTERVENANTS</h2>
    <div>-	Le responsable du traitement est identifié ci-dessus. Ses coordonnées sont les suivantes.
    <br>Adresse de correspondance : 10 route de Bonneville, 74100 Annemasse.
    <br>Adresse électronique : elhakoum@iut-acy.univ-smb.fr
    <br>Téléphone : +33(0) 698 563 623
<br>
    <br>-	Les coordonnées du délégué à la protection des données sont les suivantes : 
    <br>Adresse de correspondance : 3 rue des martyres, 74640 Annecy.
    <br>Adresse électronique : hugo.clerc-renaud@etu.univ-savoie.fr
    <br>Téléphone : +33(0)696 857 452
    </div>
    <br>
    
    <h2>3.	PRISE DE DÉCISION AUTOMATISÉE, PROFILAGE</h2>
    <div>Nous nous engageons à ne pas effectuer de profilage ni à prendre de décisions automatisées uniquement en se basant sur le traitement automatisé de vos données personnelles, sans intervention humaine. 
    De plus, nous assurons que vos données à caractère personnel ne seront en aucun cas partagées à des fins commerciales ou de marketing. 
    Notre priorité est de garantir la protection et la confidentialité de vos informations personnelles, en veillant à ce qu'elles ne soient ni utilisées de manière automatisée ni exploitées à des fins commerciales sans votre consentement explicite.
    </div><br>
    <h1>II - Collecte et utilisation de vos données personnelles</h1>
    <div>Les dispositions qui suivent sont spécifiques à chaque type de traitement de données personnelles.</div>
    <br><h2>1.	EXÉCUTION DES INSCRIPTIONS PASSÉES SUR SKILLUPNOW</h2>
    <div>Nous traitons les données personnelles suivantes : <br>
    -	prénom, nom
    Le nom et le prénom ne sont pas obligatoires lors d’une commande mais peuvent servir à mieux identifier la personne qui a acheté. À tout moment, la personne concernée peut changer d’avis concernant la communication de son nom ou/et prénom et le mettre ou non dans son tableau de bord. Dans le cas où le prénom et le nom sont absents, l’utilisateur sera identifié par notre système grâce à son adresse e-mail.
    <br>
    -	adresse e-mail et mot de passe
    L’adresse e-mail et le mot de passe sont obligatoires à des fins d’authentification. Le mot de passe respectant les principales recommandations de l’ANSSI et chiffré dans notre base de données est un minimum sécurisé et n’importe quelle adresse e-mail peut être utilisée. Ainsi, nous jugeons ces informations nécessaires à toutes commandes passées sur notre site internet.
    br>
    -	ville d’habitation (code postal, code insee, nom de la ville et pays)
    Ces informations facultatives seront servies à des fins analytiques et ne sont en aucun cas obligatoires. De même que pour le prénom et le nom, si vous pouvez ne pas fournir de ville.
    <br>
    -	modalités de paiement, informations relatives au paiement.
    Le traitement est destiné à l’exécution des inscriptions payantes passées sur notre site Internet et à la gestion de la relation avec nos clients.
    Ce traitement est nécessaire à l’exécution de mesures précontractuelles prises à votre demande et à l’exécution du contrat conclu entre nous. Il est fondé sur l’article 6, paragraphe 1, point b) du RGPD. La demande de données conditionne la conclusion du contrat. Elle a un caractère contractuel. La personne concernée est tenue de fournir les données. À défaut, elle ne pourra pas passer de commande sur notre site.
    <br>-	Enregistrement de la CB
    La carte bancaire peut être enregistrée sur notre site par choix. Nous ne gardons pas le cryptogramme au dos de la carte pour des raisons de sécurité.
    
    <br>-	Preuve de paiement
    Nous conservons la preuve de votre paiement pour la durée nécessaire à des fins comptables ou toutes réclamations de la part des clients. 
    </div>

        <br><h2>2.	ANALYSE ET AMÉLIORATION DE NOS PRODUITS ET SERVICES</h2>
        <div>Données personnelles traitées – Nous traitons les données suivantes : prénom, nom, adresse électronique, ville.
        </div>Ce traitement est utilisé à des fins d’analyse et d’étude statistique de l’utilisation de notre site et de nos formations. Le traitement est nécessaire aux fins des intérêts légitimes que nous poursuivons, consistant à améliorer et optimiser les formations. Il est fondé sur l’article 6, paragraphe 1, point f) du RGPD. La demande de données a un caractère contractuel. La personne concernée n’est pas tenue de fournir ces données et elle peut s’opposer à tout moment à leur traitement.
    <br><h2>1.	UTILISATION DE GOOGLE ANALYTICS</h2>
    <div>Google traite les données mentionnées dans <a href="https://support.google.com/analytics/answer/6004245?hl=fr/">sa politique de confidentialité</a>. Ces données comprennent notamment l’adresse IP des appareils utilisés pour consulter le site.
    Ce traitement est utilisé à des fins d’analyse et d’étude statistique de l’utilisation de notre site.
    Le traitement est nécessaire aux fins des intérêts légitimes que nous poursuivons, consistant à améliorer et optimiser notre site Internet au bénéfice des utilisateurs. Il est fondé sur l’article 6, paragraphe 1, point f) du RGPD. La demande de données a un caractère contractuel. La personne concernée n’est pas tenue de fournir ces données et elle peut s’opposer à tout moment à leur traitement. Pour empêcher la collecte de données relatives à son utilisation du site et le traitement de ces données par Google, la personne concernée doit suivre <a href="http://tools.google.com/dlpage/gaoptout">les indications de Google</a>.
    <br><a href="https://policies.google.com/privacy?hl=fr#infocollect">Page de confidentialité de Google</a>
    </div><br><h2>2.	Cookies nécessaires</h2>
    <div>Tous nos cookies sont nécessaires.
    -	laravel_session : Ce cookie est nécessaire pour gérer la session de l’utilisateur et au bon fonctionnement de SkillUpNow.
    
    -	XSRF-TOKEN : Ce cookie est utile pour la sécurité du site, il est indispensable au bon fonctionnement de SkillUpNow.
    Voir la politique de gestion et d’information des cookies pour plus d’information.
    </div><br><h2>3.	SÉCURITÉ ET PRÉVENTION DES ACTIVITÉS ILLICITES</h2>
    <div>Nous traitons les données suivantes : adresse e-mail, mot de passe. Le traitement est destiné à assurer la sécurité de nos formations et services et à prévenir les activités illicites en lien avec nos formations et services.
    Ce traitement est nécessaire au respect des obligations légales auxquelles le responsable du traitement est soumis (article 6, paragraphe 1, point c) du RGPD) et il est nécessaire aux fins des intérêts légitimes que nous poursuivons, consistant à assurer la sécurité de nos formations et de nos services et à prévenir les activités illicites (article 6, paragraphe 1, point f) du RGPD). La demande de données est conforme aux dispositions législatives et réglementaires applicables. La personne concernée est tenue de fournir ces données si elle souhaite bénéficier de nos formations et services, nous contacter par courrier électronique. Si la personne concernée ne fournit pas les données, elle ne pourra pas bénéficier de nos formations et services, ou nous contacter par courrier électronique.
    </div><br><h2>4.	Inactivité prolongée</h2>
    <div>Par défaut, vos données seront conservées pendant une période de 5 ans à compter de leur collecte. Si votre compte reste inactif pendant plus de 5 ans, nos services procéderont à sa clôture. Cette conservation est effectuée dans le but de vous permettre de bénéficier en continu des Services SkillUpNow. Vos informations relatives aux transactions financières, comme les détails de la carte bancaire utilisée pour les paiements, seront toujours conservées comme cité ci-dessus.
    
    Nous conservons vos informations personnelles pour la durée nécessaire à la réalisation des objectifs pertinents définis dans la présente Notice, ainsi que pour satisfaire aux obligations légales, telles que les exigences fiscales ou comptables. Par exemple, nous conservons votre historique d’inscription pour vous permettre de consulter vos précédentes formations et de vous réinscrire si vous le souhaitez.
    Cette politique de conservation vise à garantir la continuité de votre expérience utilisateur tout en respectant nos obligations légales et en vous offrant la possibilité de retrouver et de bénéficier pleinement de nos services.
    
        - Données d'Inscription aux Formations : 
        Les détails de votre inscription à nos formations, tels que les cours suivis, les dates d'inscription et les séquences consultées, seront conservés pour une période de 5 ans. Cette durée est conforme à l'article 2224 du Code civil français, permettant de conserver des preuves pour les actions en paiement ou en responsabilité.
    </div><br><h2>5.	Origine des données traitées</h2>
    <div>Dans le cadre de ses missions, SkillUpNow est amenée à collecter vos données que vous avez vous-même fournies. 
    Il s’agit, entre autres, des données personnelles que vous nous fournissez. Voir partie VI pour plus de détails sur les modalités des données que vous consentez à nous fournir.
    
    </div><h1>III - VOS DROITS</h1>
    <div>Vous avez des droits concernant vos données sur SkillUpNow et il est important pour nous de vous laisser les exercer. Dans le cas où vous jugez que nous ne respectons pas un des droits suivants, vous pouvez nous envoyer un message à l’adresse suivante : skillupnowDPO@gmail.com ou vous adresser à un des représentants cités dans l’article I/2 de la présente réglementation.
    </div><br><h2>1.	Droit d’accès</h2>
    <div>Vous pouvez à tout moment exercer votre droit d’accès aux informations personnelles vous concernant, afin de les compléter, de les modifier, de les rectifier, de les effacer ou de vous opposer à leur traitement pour des motifs légitimes conformément aux lois applicables en matière de protection des données.
    En outre, vous pouvez demander que le traitement de vos données soit limité et, vous pouvez nous demander de vous transférer vos données.
    </div><br><h2>2.	Droit de rectification</h2>
    <div>Dans le cas où des informations personnelles vous concernant sont détenues, vous pouvez demander leur rectification ou leur mise à jour (Articles 16 et 19 du RGPD). 
    Rappel : Vous pouvez déjà modifier vos informations personnelles dans votre tableau de bord SkillUpNow mais si pour quelconque raison vous n’y avez pas accès, vous pouvez aussi nous envoyer un courriel électronique à l’adresse suivant : skillupnowDPO@gmail.com
    Dans le cas spécifique de la rectification de données de personnes décédées, seuls les héritiers ou personnes autorisées peuvent exiger de l’organisme de prendre en considération le décès ou de procéder aux mises à jour nécessaires, conformément à l’article 85 de la loi Informatique et Libertés.
    </div><br><h2>3.	Droit à l’effacement</h2>
    <div>Si vous ne consentez plus à l’utilisation de vos données ou que ces données ne sont plus nécessaires aux fins pour lesquelles elles ont été collectées, vous pouvez exercer votre droit à l’oubli (Article 17 du RGPD). 
    Ainsi, en nous contactant, vous pouvez demander à ce qu'on supprime toutes données vous concernant sur SkillUpNow. Incluant : informations du compte (nom, prénom, ville, adresse e-mail, mot de passe), historique de formation et de séquence, avis, compétences, favoris, preuves de paiement.  Par exemple, si vous avez posté un avis que vous jugez gênant pour quelconque raison, vous pouvez demander que l’on efface cet avis. Autre exemple : votre compte s’est fait pirater ; vous pouvez demander de récupérer votre compte, et d'effacer les actions du compte pendant la durée de piratage.
    Attention votre droit à l’effacement est limité dans certaines mesures :
    -	Votre demande fait opposition à la liberté d’expression et d’information.
    -	Votre demande fait opposition à une obligation légale (exemple : le délai de conservation d’une facture est de 10 ans)
    -	Votre demande est à l’encontre de la constatation, de l’exercice ou de la défense de droits en justice. (exemple : nous avons besoin des informations de votre compte pour faire une action en justice contre vous, qui aurait fait une action illicite sur SkillUpNow)
    </div><br><h2>4.	Droit d’opposition</h2>
    <div>Dans le cas où vous vous opposez pour des motifs légitimes à un traitement concernant vos données personnelles (par exemple : à des fins de marketing direct), vous pouvez nous demander de restreindre ce traitement (Article 21 du RGPD). Nous ferons en sorte de ne plus traiter votre donnée.
    Rappel : Dans le cas où le traitement de votre nom, prénom ou ville vous dérange, vous pouvez à tout moment les changer ou les supprimer de votre compte à partir de votre tableau de bord. Votre identification se fera par votre adresse e-mail et votre ville ne sera pas utilisée aux fins précisées précédemment.
    Votre droit d’opposition ne peut pas être exercer dans certains cas :
    -	Nous avons des intérêts légitimes et indispensables à utiliser vos données. Par exemple, vous avez commis un litige sur SkillUpNow et nous avons besoin de vos données pour des actions en justice.
    -	Vous avez donné votre consentement. Si vous avez été d’accord à qu’on utilise vos données, vous devez d’abord retirer votre consentement explicitement.
    -	Par obligation légale, nous pourrions être dans l’obligation de garder vos données. Par exemple, si les forces de l'ordre nous le demandent, on peut leur fournir des données vous concernant sur les formations à lesquelles vous vous êtes inscrits. 
    -	Par intérêts vitaux de quelconque personne, il est possible de garder certaines de vos données à des fins de sécurité ou de protection. Par exemple, si quelqu’un harcèle une autre personne.
    -	Il existe un contrat entre vous et SkillUpNow pour une des formations. Nous pouvons refuser votre opposition par nécessité de traiter vos données pour mener à bien le contrat. 
    </div><br><h2>5.	Limitation de l’usage de vos données</h2>
    <div>Vous pouvez demander le “gel” de l’utilisation de vos données (Article 18 du RGPD). Cela signifie que vos données seront conservées mais pas utilisées. 
    A titre d’exemple, si vous voulez exercer votre droit de rectification (voir III.2) et que SkillUpNow prend trop longtemps à exercer votre droit, vous pouvez demander à qu’on arrête le traitement de vos données en attendant que vos données soient vérifiées et corrigées. 
    
    </div><br><h2>6.	Droit à la portabilité des données</h2>
    <div>Dans le cas où vous voulez changer de site de formations, vous pouvez nous demander de transmettre vos données, de façon structurée, à un autre responsable des traitements (un autre site). 
    </div><br><h2>7.	Retrait du consentement</h2>
    <div>Lorsque le traitement de vos données repose sur le consentement, vous avez à tout moment le droit de retirer votre consentement. Un tel retrait est sans conséquence sur la validité du traitement de vos données réalisé avant ce retrait. Voir article VI de notre protection des données personnelles pour plus de détails concernant le consentement.
    </div><br><h2>8.	Modalité d’exercice des droits</h2>
    <div>Si vous souhaitez exercer ces droits, vous devez envoyer une demande avec une copie de votre carte d'identité, de votre passeport ou de toute autre pièce d'identité :
        Par e-mail à l’adresse suivante : elhakoum@iut-acy.univ-smb.fr
        Ou skillupnowDPO@gmail.com
        
    Nous vous demandons une preuve de votre identité afin d'être certain de respecter vos données et de ne pas les envoyer à un tiers. Il faut que la photo ou la photocopie de votre document d’identité soit assez clair pour pouvoir lire votre nom, votre prénom au minimum. Un document plus clair augmentera les chances que votre demande soit approuvée.
    </div><br><h2>9.	Délai de traitement des demandes</h2>
    <div>Si vous nous contactez pour exercer vos droits, nous vous informerons dans un délai d’un mois à compter de la réception de votre demande des suites données à celle-ci. Au besoin, ce délai peut être prolongé de deux mois, compte tenu de la complexité et du nombre de demandes (article 12, 3 du RGPD). Dans ce cas, nous vous informerons dans un délai d’un mois à compter de la réception de votre demande. Nous nous réservons le droit de ne pas répondre aux demandes manifestement infondées ou excessives. Votre demande sera conservée tant qu’un recours est possible.
    </div><br><h2>10.	Recours possibles en cas de non-respect de vos droits</h2>
    <div>À tout moment, si vous considérez que vos droits n'ont pas été respectés, vous pouvez également déposer une réclamation auprès de la Commission Nationale Informatique et Libertés (CNIL).
    </div><br><h1>IV - Mesures de sécurité</h1>
    <h2>1.	Conseils quant au choix du mot de passe</h2>
    <div>    Il est conseillé de mettre un mot de passe sécurisé respectant les recommandations de l’ANSSI.
    </div><h3>1.	Complexité et longueur</h3>
    <div>Le mot de passe doit être complexe (minuscules et majuscules, chiffres, symboles). Il doit aussi être d’une longueur minimale de 12 lettres. Évitez aussi les paternes comme une suite de nombres 1234 ou la répétition d’une même lettre comme AAABBB. 
    
    </div><h3>2.	Evitez d’utiliser des données personnelles ou des noms communs
    <div>Les données personnelles tels que le nom d’un proche ou la date de naissance sont à éviter car elles peuvent compromettre le mot de passe. Les noms communs sont aussi à éviter.
    </div>
    <br><h3>3.	Ne réutilisez pas les mêmes mots de passe
    <div>Si un de vos comptes contenant le même mot de passe se fait pirater, il sera simple de voler vos autres comptes possédant le même mot de passe. Il est donc nécessaire de choisir un mot de passe différent pour chaque service. S’il vous est difficile de retenir vos mots de passe, vous pouvez :
    <br>
    -	Utiliser une phrase mnémotechnique :
    Cette technique consiste à prendre une phrase banale comme “JaimePartirEnVacance” puis de lui appliquer un changement en décalant ses lettres ou en remplaçant certaines lettres par des symboles. Ce qui donnerait par exemple “J41m3pART1#AnWaç4mce”. 
    <br>
    -	Utiliser un gestionnaire de mot de passe :
    Des gestionnaires de mot de passe très efficaces existent. Ils permettent de garder vos mots de passe en sécurité en les chiffrant tout en ayant plusieurs couches de protection.
    </div>
    <br><h2>2.	Double authentification</h2>
    <div>La double authentification peut être utilisée pour protéger un mot de passe de façon très efficace. Lorsque vous essayez de vous connecter avec votre mot de passe, le site en question vous envoie un e-mail ou un SMS avec un code. Ainsi, dans le cas où le pirate n’a pas le mot de passe de votre boite mail ou l’accès à votre téléphone, il est pour lui impossible de se connecter même en ayant le mot de passe. 
    Cependant, il est très recommandé de changer le mot de passe dans le cas d’une suspicion de tentative de piratage. 
    
    De plus, il existe la triple authentification dans certains sites qui permet de remédier aux problèmes de la double authentification.
    </div><br><h2>3.	Changement du mot de passe</h2>
    <div>Le mot de passe devrait être changé à chaque suspicion de tentative de piratage ou en général, assez fréquemment (toutes les 2 semaines/ tous les 2 mois).
    Si vous l’avez oublié, vous pouvez aussi réinitialiser votre mot de passe. Ce traitement se fait en toute sécurité. 
    </div><br><h2>4.	 Sécurisation de votre mot de passe</h2>
    <br><h3>1.	Respect des normes et des recommandations
    <div>De notre côté, nous mettons en œuvre les moyens nécessaires pour sécuriser vos données. Nous suivons scrupuleusement les recommandations de l’Agence Nationale de la Sécurité des Systèmes d'Information (ANSSI) pour assurer une protection optimale.  Lors de la création de votre mot de passe, nous vous indiquons d’utiliser un mot de passe de 12 caractères incluant lettres minuscules et majuscules, chiffres et symboles, garantissant ainsi un niveau de sécurité élevé.
    </div><br><h3>2.	Hachage :</h3>
    <div><br>●	Le hachage est un processus qui prend une donnée, comme un mot de passe, et la transforme en une chaîne de caractères apparemment aléatoire.
    <br>●	Cette chaîne, appelée "hash", est unique pour chaque donnée et est générée de manière unidirectionnelle, ce qui signifie qu'il est pratiquement impossible de remonter du “hash” à la donnée d'origine.
    <br>●	Il garantit l'intégrité des données et est souvent utilisé pour vérifier si des informations n'ont pas été altérées.
    <br><h3>3.	Cryptage </h3>
    <div><br>●	Le cryptage consiste à transformer des données lisibles en un format codé à l'aide d'un algorithme et d'une clé de chiffrement.
    <br>●	Cela rend les données illisibles sans la clé de déchiffrement correspondante, assurant ainsi leur confidentialité.
    <br>●	Contrairement au hachage, le cryptage est réversible, ce qui signifie que les données peuvent être déchiffrées avec la clé appropriée. Cela est nécessaire pour reconnaître le mot de passe de l’utilisateur lors de sa connexion.
    En combinant le hachage pour l'intégrité des données et le cryptage pour la confidentialité, les systèmes sécurisés peuvent stocker les informations de manière qu'elles soient protégées contre les accès non autorisés et les attaques potentielles.
    </div>
    <br><h1>V - Partage de vos données et sous-traitance</h1>
    <div>Nous ne partageons vos données personnelles qu’aux personnes contribuant à l’enseignement des formations à des fins d’identification. Sans cela, notre service deviendrait inutilisable puisqu’on ne pourrait pas vous identifier. 
        Les informations partagées se limitent au minimum à l’adresse e-mail mais une ville, un nom et un prénom peuvent être fournis.
    
    Nous disposons de deux sous-traitants qui sont OVH et les concepteurs-intervenants des formations. Cela permet à l’Utilisateur, en cas de souci, d’envoyer un signalement pour résoudre ce dernier. Les concepteurs ci-présents proposent des formations et des parcours dans SkillIUpNow.
    
    Nous ne partageons pas vos informations hors de l'Union européenne ou à quelconque autre entreprise.
    </div><br><h1>VI - Consentement et retrait</h1>
    <div>L’utilisateur doit consentir à l’utilisation de ses données personnelles. Le consentement est quelque chose qui nous tient à cœur chez SkillUpNow. 
    Nous nous appuyons sur :
    
    Les articles 4, 6 et 7 et considérants 42) et 43) du RGPD.
    Les lignes directrices sur le consentement prévu par le règlement (UE) 2016/679 (WP 259)
    Les bases légales de la CNIL
    </div><br><h2>1.	Qu’est-ce que le consentement ?</h2>
    <div>Le RGPD définit le consentement comme “toute manifestation de volonté, libre, spécifique, éclairée et univoque par laquelle la personne concernée accepte, par une déclaration ou par un acte positif clair, que des données à caractère personnel la concernant fassent l'objet d'un traitement “
    Dans le cadre de notre site, le consentement se définit aussi par le droit au retrait de ce dernier à tout moment. Le consentement peut être retiré dans le tableau de bord. Cependant, après le retrait du consentement, vous serez déconnecté, ne pourrez plus utiliser votre compte personnel sans consentir à notre politique. L’utilisation de votre e-mail est notamment nécessaire à l’utilisation de nos services (Voir II/1 et II/3 pour l’utilisation des données nécessaires).
    Enfin, le consentement peut être prouvé si vous avez accès à nos services réservés aux personnes connectés.
    
    </div><br><h2>2.	Modalité du recueillement du consentement</h2>
    <div>Votre consentement peut ne pas être recueilli dans certains cas spécifiques comme l’exécution d’un contrat de formation passé sur notre site. Dans tous les autres cas, notamment pour une prospection commerciale par courriel, nous devons le demander.
    
        En France, à partir de 15 ans, un mineur peut consentir. Cependant, si l’enfant a moins de 15 ans, la loi “informatique et libertés” impose le recueil du consentement de l’enfant et du titulaire de l’autorité parentale. Il est donc interdit pour un enfant de moins de 15 ans de consentir de lui-même.
    </div><br><h2>3.	Votre consentement est valide</h2>
    <div>Il y a 4 critères cumulatifs pour qu’un consentement soit valable. 
    <ul>
    <li>Il doit être libre, ni contraint, ni influencé. Il est obligatoire d’accepter nos conditions et règlements pour la bonne utilisation de vos services SkillUpNow mais vous avez aussi le droit de ne pas créer de compte ou d’exercer votre droit à la portabilité des données. Vous êtes libre de vous inscrire ou non ; Ainsi, nous n’influençons pas votre décision à accepter ou non.
    </li><li>Il doit être spécifique. Il y a un consentement recueilli pour la protection des données personnelles et un recueilli pour les conditions générales d’utilisation. 
    </li><li>Il doit être éclairé. Nous vous mettons à disposition une page de présentation des protections des données personnelles et une pour les conditions d’utilisation. 
    </li><li>Il doit être univoque, c’est-à-dire qu’il doit être d’un acte positif clair sans ambiguïté. Nous vous demandons votre consentement à travers des cases à cocher.
    </li></ul>
    
    Sur SkillUpNow, nous recevons votre consentement dès la création de votre compte sur notre site avec les cases à cocher. En acceptant ces présentes conditions, vous acceptez qu’on utilise vos données selon ce qui a été convenu dans cette page. Dans le cas où un changement à lieu après que vous aillez accepter nos règlements ou nos conditions, nous mettons en place les moyens nécessaires afin que vous nous transmettiez votre consentement concernant les changements (Voir VII).
    </div>
    
    <br><h1>VII. Changements</h1>
    <div>En cas de changement de cette présente politique, nous vous enverrons un mail par l’adresse du compte correspondant. Après la réception du mail, une notification apparaîtra à votre retour sur notre site demandant d’accepter les nouvelles politiques de protection des données. Ainsi, en acceptant cette nouvelle notification, vous acceptez la nouvelle politique. Autrement, vous pourrez nous communiquer vos préférences à l’adresse SkillUpNow@gmail.com pour une éventuelle fermeture de compte et suppression de données.
    VIII. Dispositions finales 
    Dispositions légales
    ●	Loi applicable : Ce document est régi par la législation française relative à la protection des données personnelles, notamment le Règlement Général sur la Protection des Données (RGPD) et la Loi Informatique et Libertés.
    ●	Juridiction compétente : Tout litige découlant de ce document ou lié à la collecte, au traitement ou à l'utilisation des données personnelles sera soumis à la compétence exclusive des tribunaux français, notamment ceux du ressort d’Annecy
    </div>
</div>

<script src="{{ asset('js/mainBar.js') }}"></script>
<?php include(app_path().'/includes/footer.php'); ?>
