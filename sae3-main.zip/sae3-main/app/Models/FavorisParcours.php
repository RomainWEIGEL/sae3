<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FavorisParcours extends Model
{
    use HasFactory;
    protected $table = "favorisParcours";
    protected $primaryKey = ["idutilisateur","idparcours"];
    public $incrementing = false;
    public $timestamps = false;

    
    protected $fillable = [
        "idutilisateur",
        "idparcours"
    ];
    public function utilisateur()
    {
        return $this->belongsTo(User::class, 'idutilisateur', 'idutilisateur');
    }
    public function parcours()
    {
        return $this->belongsTo(Parcours::class, 'idparcours', 'idparcours');
    }
}
