    <?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>Création du compte</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Vérification de la présence du message de succès
            @if(session('error'))
                // Affichage de la popup avec le message de succès
                alert('{{ session('error') }}');
            @endif
        });
    </script>
</head>
<body>
<?php include(app_path().'/includes/mainBar.php'); ?>
<form action="/creationcompte" method="POST" class="form" id="creationUtilisateurform">
    <h1 id="creationcomptetitre" class="signup">Créez votre compte</h1>

    @csrf

    <div id="choixEtat">
        <label for="choix">Sélectionnez votre poste :</label>
        <input id="choix" name="choix" list="etats">
        <datalist id="etats">
            <option value="utilisateur">utilisateur</option>
            <option value="admin">admin</option>
            <option value="concepteur">concepteur/Ecole</option>
        </datalist>
    </div>

   

    <div id="nomCreationCompte">
        <label for="nomutilisateur">Nom :</label><br>
        <input type="text" id="nomutilisateur" name="nomutilisateur" autofocus maxlength="75" minlength="0" class="form--input" placeholder="Nom" value="{{ old('nomutilisateur') }}"><br>
    </div>

    <div id="prenomCreationCompte">
        <label for="prenomutilisateur">Prénom :</label><br>
        <input type="text" id="prenomutilisateur" name="prenomutilisateur" maxlength="50" minlength="0" class="form--input" placeholder="Prénom" value="{{ old('prenomutilisateur') }}"><br>
    </div>

    <div id="nomVilleCreationCompte">
        <label for="codecommune">Ville :</label><br>
        <input placeholder="Tapez le nom d'une ville" type="text" id="codecommune" pattern="[1-9]\d{0,4}|[1-3]\d{5}" name="codecommune" class="form--input" value="{{ old('codecommune') }}">
        
        <!-- Chargement des bibliothèques javascript jquery -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        
        <!-- Script d'affichage et d'autocomplétion des villes -->
        <script>
            $(function() {
                // TOUTES LES VILLES
                const villes = [
                    @foreach ($villes as $ville)
                        { label: "{{$ville->nomville." (".$ville->codePostal.") "}}", value: "{{$ville->codecommune}}" },
                    @endforeach
                ];
                
                // AUTOCOMPLETION
                $('#codecommune').autocomplete({
                    // La source des données pour l'autocomplétion
                    source: function(request, response) {
                        // VERIFICATIONS:
                        // Échapper les caractères spéciaux pour éviter les problèmes de regex
                        const userInput = $.ui.autocomplete.escapeRegex(request.term);
                        // Expression régulière pour filtrer les résultats basés sur la saisie de l'utilisateur
                        const matcher = new RegExp('^' + userInput, 'i');
                        
                        // FILTRE:
                        // Réponse avec les éléments filtrés selon la saisie de l'utilisateur
                        response($.grep(villes, function(item) {
                            return matcher.test(item.label);
                        }));
                    },
                    // Nombre minimum de caractères avant de déclencher l'autocomplétion
                    minLength: 2 // Minimum de caractères avant de déclencher l'autocomplétion
                });
            });
        </script>
    </div>
    @error('codecommune')
    <div style="color:red;">{{ $message }}</div>
    @enderror

    <div id="mailCreationCompte">
        <label for="mailutilisateur">E-mail* :</label><br>
        <input type="email" id="mailutilisateur" name="mailutilisateur" placeholder="exemple@domaine.com" maxlength="75" required class="obligatoire form--input" value="{{ old('mailutilisateur') }}"><br>
    </div>
    @error('mailutilisateur')
    <div style="color:red;">{{ $message }}</div>
    @enderror

    <div id="mdpCreationCompte">
        <label for="mdpu">Mot de passe* :</label><br>
        <input type="password" id="mdpu" name="mdpu" pattern="(?=.*\d)(?=.*[a-zA-Z])(?=.*[\W_]).{12,}"
               title="Le mot de passe doit contenir au moins 12 caractères avec des chiffres, des lettres et des symboles."
               required class="obligatoire form--input" value="{{ old('mdpu') }}"><br>
        <small class="texteConnec">Saisissez au moins 12 caractères avec minimum 1 chiffre, 1 majuscule, 1 symbole.</small>
    </div>
    <br>
    <div>
    @error('mdpu')
    <div style="color:red;">{{ $message }}</div>
    @enderror
    </div>
    <br>

    <div>
        <input

            type="checkbox"
            required
            id="politique"
            name="politique"
            value={{ old("politique") ? 'checked' : '' }} />
        <label for="politique">
            Acceptez-vous <a href="/politique_protection_donnees_personnelles">notre politique de protection des données personnelles</a>?
        </label>
    </div>

    <div>
        <input
            type="checkbox"
            required
            id="collecte"
            name="collecte"
            value={{ old("collecte") ? 'checked' : '' }} />
        <label for="collecte">
            Acceptez-vous la collecte de vos données ?
        </label>
    </div>
    
    <input type="submit" value="Créer" class="form--submit">
    <p class="texteConnec">Vous possédez un compte? <a href="connexioncompte">Se Connecter</a></p>
</form>

    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
</body>
</html>
