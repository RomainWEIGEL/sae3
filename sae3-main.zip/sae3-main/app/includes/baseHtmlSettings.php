<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('style.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleMainBar.css'); ?>">
    <link rel="icon" href="<?php echo asset('img/logocrop.png'); ?>">