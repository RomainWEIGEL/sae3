document.addEventListener("DOMContentLoaded", function () {
    // Sélectionnez tous les éléments avec la classe 'review-bar'
    var reviewBars = document.querySelectorAll('.review-bar');

    // Parcourez chaque élément et créez l'élément de notation à l'intérieur
    reviewBars.forEach(function (reviewBar) {
        var rating = reviewBar.dataset.rating;
        var ratingElement = document.createElement("div");
        ratingElement.className = "rating";
        ratingElement.style.width = rating + "%";

        // Ajoutez l'élément de notation à l'intérieur de la barre de review
        reviewBar.appendChild(ratingElement);
    });
});


document.addEventListener("DOMContentLoaded", function () {
    var ctx = document.getElementById("myChart");

    // Supposons que vous avez trois notes à représenter
    var notes = [ctx.dataset.contenu, ctx.dataset.plateforme, ctx.dataset.animation];
    ctx = ctx.getContext('2d')
    // Créer le graphique
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Note contenu', 'Note plateforme', 'Note animation'],
            datasets: [{
                label: 'Moyennes des avis',
                data: notes,
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            plugins: {
                legend: {
                display: false,
                }
            },
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    max: 5,
                    display: false
                }
            }
        }
    });
});