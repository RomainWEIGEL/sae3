<?php

namespace App\Http\Controllers;

use App\Models\Parcours;
use Illuminate\Http\Request;

class accueilController extends Controller
{
    public function getParcours(){

        $parcours=Parcours::where('idparcours', '=', 1)
        ->orWhere('idparcours', '=', 6)->orWhere('idparcours', '=', 9)->get();
        //dd($parcours);
        return view('accueil', ["parcours"=> $parcours]);
    }
}