<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>SkillUpNow</title>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>
        {{ $utilisateur }}
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
</body>
</html>
