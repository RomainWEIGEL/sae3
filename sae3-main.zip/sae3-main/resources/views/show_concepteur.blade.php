<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
<title>SkillUpNow - Concepteur</title>
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>
        <h1>{{$concepteur->nomecole}}</h1>
        <div class="baseDiv">
            <p class="baseP">{{$concepteur->resumeconcepteur}}</p>
        </div>
        <img style="height: 70vh" src="{{ asset('img/institut.jpg') }}" alt="institut">
        <?php include(app_path().'/includes/footer.php'); ?>
    <script src="{{ asset('js/main.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
</body>
</html>