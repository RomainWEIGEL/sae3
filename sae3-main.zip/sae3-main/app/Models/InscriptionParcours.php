<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InscriptionParcours extends Model
{
    use HasFactory;

    protected $table = "inscription_parcours";
    protected $primaryKey = "idinscriptionparcours";
    public $timestamps = false;

    
    protected $fillable = [
        "idutilisateur",
        "idparcours",
        "dateinscriptionparcours"
    ];

    public function dateInscriptionParcours(){
        return $this->belongsTo(Date::class, 'iddate', 'dateinscriptionparcours');
    }

    public function utilisateur(){
        return $this->belongsTo(User::class, 'idutilisateur', 'idutilisateur');
    }

    public function parcours(){
        return $this->belongsTo(Parcours::class, 'idparcours', 'idparcours');
    }
}
