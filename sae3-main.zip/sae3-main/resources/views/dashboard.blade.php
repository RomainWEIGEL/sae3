<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Tableau de bord utilisateur</title>
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleDashboard.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleFormation.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleparcours.css'); ?>">
</head>
<body>
    <?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <?php include(app_path().'/includes/mainBar.php'); ?>

    {{--SI L'UTILISATEUR N'EST PAS CONNECTE, ON LE REDIRIGE VERS LE FORMULAIRE DE CONNEXION--}}
    @if (Auth::guest())
        <script>window.location.href = "/connexioncompte";</script>
        <?php exit; ?>
    @endif

    <input class="button-19" type="button" onclick='window.location.href="/logout";' value="Se deconnecter">
    <details open>
        <summary >Vos informations</summary>
            <form method="POST"  id="dashmodif" action="{{ route("/update") }}">
                @csrf

                <label for="nomutilisateur">Nom:</label>
                <br><input type="text" id="nomutilisateur" name="nomutilisateur" class="form--input" minlength='0' maxlength='75' pattern="[A-Za-zÀ-ÖØ-öø-ÿ\s'-]+" value="{{Auth::user()->nomutilisateur}}"><br>

                <label for="prenomutilisateur">Prénom:</label>
                    <br><input type="text" id="prenomutilisateur" name="prenomutilisateur" class="form--input" minlength='0' maxlength='50' pattern="[A-Za-zÀ-ÖØ-öø-ÿ\s'-]+" value="{{Auth::user()->prenomutilisateur}}"><br>

                @if (!Auth::user()->codecommuneL)<label for="codecommune">Ville: Non précisé</label><br>
                @else<label for="codecommune">Ville: {{Auth::user()->codecommuneL->nomville}}</label><br>
                @endif
                
                <input placeholder="Choisissez une ville" pattern="[0-9]{5}" type="text" id="codecommune" name="codecommune" value="{{Auth::user()->codecommune}}" class="form--input">
            
                {{-- Chargement des bibliothèques javascript jquery --}}
                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
                <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
                
                {{-- Script d'affichage et d'autocomplétion des villes --}}
                <script>
                $(function() {
                    // TOUTES LES VILLES
                    const villes = [
                        @foreach ($villes as $ville)
                            { label: "{{$ville->nomville." (".$ville->codePostal.") "}}", value: "{{$ville->codecommune}}" },
                        @endforeach
                    ];
                    
                    // AUTOCOMPLETION
                    $('#codecommune').autocomplete({
                        // La source des données pour l'autocomplétion
                        source: function(request, response) {
                            // VERIFICATIONS:
                            // Échapper les caractères spéciaux pour éviter les problèmes de regex
                            const userInput = $.ui.autocomplete.escapeRegex(request.term);
                            // Expression régulière pour filtrer les résultats basés sur la saisie de l'utilisateur
                            const matcher = new RegExp('^' + userInput, 'i');
                            
                            // FILTRE:
                            // Réponse avec les éléments filtrés selon la saisie de l'utilisateur
                            response($.grep(villes, function(item) {
                                return matcher.test(item.label);
                            }));
                        },
                        // Nombre minimum de caractères avant de déclencher l'autocomplétion
                        minLength: 2 // Minimum de caractères avant de déclencher l'autocomplétion
                    });
                });
                </script>

                <br>
                <label for="mailutilisateur">Mail:</label>
                    <br><input type="email" id="mailutilisateur" name="mailutilisateur" class="form--input" minlength='5' maxlength='75' value="{{Auth::user()->mailutilisateur}}"><br>


                <label for="mdpu">Changer le mot de passe:</label>
                    <br><input type="password" id="mdpu" name="mdpu" minlength='12' class="form--input" value="{{Auth::user()->mdpu}}"><br>

                <input type="Submit" value="Modifier">
                
            </form> 
        </details>

    <hr>
    {{-- VOS COMPETENCES --}}
        <h1>Vos compétences</h1>
        @if(count(Auth::user()->Competences) != 0)
            @foreach(Auth::user()->Competences as $comp)
                <div class="divCompetence"><p class="pCompetence">{{$comp->nomcompetence}}</p></div>
            @endforeach
        @else
            <p>Vous n'avez pas de compétences pour le moment</p>
        @endif
        <div class="blackLine"></div>
                    
    <details><summary>Vos Favoris</summary>
        <details><summary>Vos Formation Favoris</summary>
            <div class="forma">
                @foreach(Auth::user()->Favoris as $favori)
                <a href="/formation/{{$favori->idformation}}">
                    <div class="unselectable formation" id="{{$favori->formation->idformation}}">

                        <form method="POST" class="formformation" action="/favoris/delete/{{$favori->formation->idformation}}-{{Auth::user()->idutilisateur}}">
                            @csrf @method('DELETE') 
                            <button type="submit" class="croixFormation" value="{{$favori}}">X</button>
                        </form>


                        <img class="formationImg" src="./img/formation1.jpg" alt="">
                        <div class="textBlock">
                        
                        @if($favori->formation->prixformation == 0)
                            <h2 class="formationTitle" >{{$favori->formation->titreformation}} - Gratuite</h2>
                        @else
                            <h2 class="formationTitle">{{$favori->formation->titreformation}} <br> {{$favori->formation->prixformation}} €</h2>
                        @endif

                        @if (strlen($favori->formation->resumeformation) < 170)
                            <p class="textLigne">{{$favori->formation->resumeformation}}</p>
                        @else
                            <p class="textLigne">{{substr($favori->formation->resumeformation, 0, 170)}}...</p> 
                        @endif

                        <p class="textLigne interVenant"> <b>Intervenants </b> : {{$favori->formation->intervenant->nomintervenant}}</p>
                        <div class="interVenantPopup "><p class="underline">{{$favori->formation->intervenant->nomintervenant}} {{$favori->formation->intervenant->prenomintervenant}}</p> {{$favori->formation->intervenant->resumeintervenant}}</div>
                        <p><a href="/concepteur/{{$favori->formation->idconcepteur}}"><b>Concepteur </b> : {{$favori->formation->concepteur->nomecole}}</a></p>
                        <p class="textLigne"> <b>Niveau </b> : {{$favori->formation->niveauformation->nomniveau}}</p>
                        </div>
                    </div>
                </a>
                @endforeach
            </details>
                <details><summary>Vos parcours favoris</summary>
                    @foreach(Auth::user()->ParcoursFavoris as $par)
                        <a href="/parcours/{{$par->idparcours}}">
                        <div class="infosParcours">
                            <p class="simpleTextInParcours"><b>Langue : </b>{{$par->parcours->langue->nomlangue}}</p>
                            <p style="font-size: 1.2em">{{$par->parcours->resumeparcours}}</p>
                            <pre class="simpleTextInParcours"><b>Début </b>{{\Carbon\Carbon::parse($par->parcours->dateDebutFormation->date)->format('d/m/Y')}} --> <b>Fin</b> {{\Carbon\Carbon::parse($par->parcours->dateFinFormation->date)->format('d/m/Y')}}</pre>
                            <?php
                                {{$tempsTotal = 0;}}
                                foreach($par->parcours->formations as $form){
                                    foreach ($form->Sequence as $seq) {
                                        $tempsTotal += $seq->dureesequence;
                                    }
                                }
                                echo "<p class='simpleTextInParcours'><b>Durée du parcours :</b> {$tempsTotal} heures</p>";
                            ?>
                            <?php
                                {{$prixTotal = 0;}}
                                foreach($par->parcours->formations as $form){
                                    $prixTotal += $form->prixformation;
                                }
                                echo "<p class='simpleTextInParcours'><b>Prix total du parcours :</b> {$prixTotal} €</p>";
                            ?>
                            @if($par->parcours->certification != null)
                                <p class="simpleTextInParcours"><b>Certification à la clef par :</b> {{$par->parcours->certification->organisme->nomorganisme}}</p>
                            @endif
                        </div>
                            </a>                    
                    @endforeach
                </details>
            </div>
        
    </details>
    <details open><summary>Vos inscriptions</summary>
        <details open><summary>Vos formations</summary>
            <div class="forma">

                @foreach(Auth::user()->Formation as $formationsInscr)
                <a href="/formation/{{$formationsInscr->idformation}}">
                    <div class="unselectable formation" id="{{$formationsInscr->idformation}}">
    
                        <form method="POST" class="formformation" action="/favoris/delete/{{$formationsInscr->idformation}}-{{Auth::user()->idutilisateur}}">
                            @csrf @method('DELETE') 
                            <button type="submit" class="croixFormation" value="{{$formationsInscr}}">X</button>
                        </form>
    
                        <img class="formationImg" src="./img/formation1.jpg" alt="">
                        <div class="textBlock">
                        
                        @if($formationsInscr->prixformation == 0)
                            <h2 class="formationTitle" >{{$formationsInscr->titreformation}} - Gratuite</h2>
                        @else
                            <h2 class="formationTitle">{{$formationsInscr->titreformation}} <br> {{$formationsInscr->prixformation}} €</h2>
                        @endif
    
                        @if (strlen($formationsInscr->resumeformation) < 170)
                            <p class="textLigne">{{$formationsInscr->resumeformation}}</p>
                        @else
                            <p class="textLigne">{{substr($formationsInscr->resumeformation, 0, 170)}}...</p> 
                        @endif
 
                        <p class="textLigne"> <b>Niveau </b> : {{$formationsInscr->niveauformation->nomniveau}}</p>
                        </div>
                        <br>
                        <p>Progression:</p>
                        <?php 
                        $tot = 0;
                        $nbr = 0;
                        foreach (Auth::user()->sequence as $seq){
                            foreach ($seq->formations as $form){
                                if($form->idformation == $formationsInscr->idformation){
                                    if($seq->pivot->termine == "OUI"){
                                        $nbr += 1;
                                    }
                                }
                            }
                        }
                        foreach ($formationsInscr->sequence as $seq) {
                            $tot += 1;
                        }
                        if($tot != 0){
                            $tot = round(($nbr/$tot)*100,1);
                            echo "<div class='review-bar' data-rating=".$tot."></div>";
                        }
                        else {
                            echo "<div>Cette séquence est en cours de création</div>";
                        }
                        ?>
                    </div>
                </a>
                @endforeach
            </div>
        </details>
        <details><summary>Vos Parcours</summary>
        </details>
    </details>

        <script src="{{ asset('js/review.js') }}"></script>
        <script src="{{ asset('js/mainBar.js') }}"></script>
        <?php include(app_path().'/includes/footer.php'); ?>
    </body>
    </html>

