
<footer class="Sitefooter">
    <br>
    <ul>
        <li><a href="/politique_protection_donnees_personnelles" class="lienPoliProtec">Politique de confidentialité</a></li>
    </ul>
</footer>