<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NiveauFormation extends Model
{
    use HasFactory;

    protected $table = "niveauformation";
    protected $primaryKey = "idniveau";
    public $timestamps = false;

    
    protected $fillable = [
        "nomniveau"
    ];
    // Relation avec les formations
    public function formations()
    {
        return $this->hasMany(Formation::class, 'idniveau', 'idniveau');
    }
}
