<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\CategorieFormation;

class Categorie extends Model
{
    use HasFactory;

    protected $table = "categorie";
    protected $primaryKey = 'idcategorie';

    protected $fillable = [
        "idcategorie",
        "idsouscategorie",
        "nomcategorie"
    ];
    
    // public function formations()
    // {
    //     return $this->belongsToMany(Formation::class, 'categorie_formation');
    // }
}
