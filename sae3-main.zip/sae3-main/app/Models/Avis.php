<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Avis extends Model
{
    use HasFactory;

    protected $table = "avis";
    protected $primaryKey = "idavis";
    public $timestamps = false;
    
    
    protected $fillable = [
        "idformation",
        "idutilisateur",
        "texteavis",
        "notecontenu",
        "noteplateforme",
        "noteanimation",
        "dateavis"
    ];
    // Relation avec la formation
    // public function formation()
    // {
    //     return $this->belongsTo(Formation::class, 'idformation', 'idformation');
    // }
    public function utilisateur()
    {
        return $this->hasOne(User::class, 'idutilisateur', 'idutilisateur');
    }
    public function dateAvis()
    {
        return $this->hasOne(Date::class, 'iddate', 'dateavis');
    }
}
