<form action="/login" method="POST" class="form popup" style="display: none" id="connectForm">
    <span id="croix">X</span>
    <h1 id="creationcomptetitre" class="signup"> Se Connecter </h1> 
    <div id="mailCreationCompte">
        <label for="mailutilisateur">E-mail :</label><br>
        <input type="email" id="mailutilisateur" name="mailutilisateur"  placeholder="exemple@domaine.com" maxlength="75" required class="form--input" ><br>
    </div>

    <div id="mdpCreationCompte">
        <label for="passwd">Mot de passe :</label><br>
        <input type="password" id="passwd" name="passwd" required class="form--input" ><br>
    </div>

    <input type="submit" value="Se connecter" class="form--submit">
    <p class="texteConnect">Vous ne possédez pas de compte? <a href="/creationcompte">Créer un compte</a></p>
</form>