<?php

namespace App\Http\Controllers;

use App\Models\Formation;
use Illuminate\Http\Request;

use App\Models\Avis;
use App\Models\Date;
use App\Models\lien_formation_sequence;
use App\Models\Sequence;
use App\Models\Intervenant;
use App\Models\User;
use App\Models\NiveauFormation;
use App\Http\Controllers\FavorisController;
use Illuminate\Support\Facades\Auth;

class FormationController extends Controller
{
    public function getFormations(){
        $formations = Formation::with('intervenant', 'concepteur', 'niveauformation')->get();

        //$formations = Formation::all();

        return view('formations', ["formations"=> $formations]);
    }

    public function showFormation(Request $request, $id){

        $formation = Formation::findOrFail($id);

        return view("show_formation", ["formation" => $formation]);
        //"utilisateurs"=>$utilisateur
    }

    public function addToFavorites(Request $request)
    {
        $formation = intval($request->fav);
        $user = Auth::user();

        //dd($formation, $user->idutilisateur);
        $request1 = new Request([
                'idutilisateur' => $user->idutilisateur,
                'idformation' => $formation
            ]);

        // $request->replace(['idformation'=>($formation->idformation),
        // 'idutilisateur'=>($user->idutilisateur)]);

        return (new FavorisController)->createFavoris($request1);
    }
}
