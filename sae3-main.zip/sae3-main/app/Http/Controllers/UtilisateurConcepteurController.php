<?php

namespace App\Http\Controllers;

use App\Models\UtilisateurConcepteur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class FavorisController extends Controller
{
    public function createUtilisteurConcepteur(Request $request) {
        $validatedData = $request->validate([
            'idutilisateur' => ['required', 'integer'],
            'idconcepteur' => ['required', 'integer']
        ]);

        $userId = $validatedData['idutilisateur'];
        $concepteurId = $validatedData['idconcepteur'];
    
       // Vérifier si ce favori existe déjà pour cet utilisateur et cette formation
       $existingUtilisteurConcepteur = UtilisateurConcepteur::where('idutilisateur', $userId)
       ->where('idconcepteur', $concepteurId)
       ->first();

        if (!$existingUtilisteurConcepteur) {
            // Si le favori n'existe pas, créez-le
            UtilisateurConcepteur::create($validatedData);
        }
        
    
        return back();
    }

}
