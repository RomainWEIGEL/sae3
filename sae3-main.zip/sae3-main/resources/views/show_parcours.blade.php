<?php include(app_path().'/includes/baseHtmlSettings.php'); ?>
    <title>SkillUpNow</title>
    <link rel="stylesheet" type="text/css" href="<?php echo asset('styleparcours.css'); ?>">
</head>
<body>
    <?php include(app_path().'/includes/mainBar.php'); ?>

    <h1 class="simpleTitleInParcours">{{$parcours->titreparcours}}</h1>
    <?php
    if (Auth::guest()){
        $estConnecte = "false";
    }
    else{
        $estConnecte = "true";
    }
    ?>
    @if($estConnecte == "true")
        <form action="{{ route("/FavorisParcours") }}" method="POST">
            @csrf
            @if (!App\Models\FavorisParcours::where('idutilisateur', Auth::user()->idutilisateur)
            ->where('idparcours', $parcours->idparcours)
            ->first())
                <button type=submit id="favpar" name="favpar" value={{(int)($parcours->idparcours)}} class="styleBouton"><img src="{{ asset('img/favoris.png') }}" style="width:20px;"> Ajouter aux favoris </button>
            @else
                <button type=submit id="favpardis" name="favpardis" disabled value={{(int)($parcours->idparcours)}} class="styleBouton"><img src="{{ asset('img/FavorisLike.png') }}" style="width:20px;"> Parcours favoris </button>
            @endif
        </form>
    @endif
    <div class="infosParcours">
        <p class="simpleTextInParcours"><b>Langue : </b>{{$parcours->langue->nomlangue}}</p>
        <p style="font-size: 1.2em">{{$parcours->resumeparcours}}</p>
        <pre class="simpleTextInParcours"><b>Début </b>{{\Carbon\Carbon::parse($parcours->dateDebutFormation->date)->format('d/m/Y')}} --> <b>Fin</b> {{\Carbon\Carbon::parse($parcours->dateFinFormation->date)->format('d/m/Y')}}</pre>
        <?php
            {{$tempsTotal = 0;}}
            foreach($parcours->formations as $form){
                foreach ($form->Sequence as $seq) {
                    $tempsTotal += $seq->dureesequence;
                }
            }
            echo "<p class='simpleTextInParcours'><b>Durée du parcours :</b> {$tempsTotal} heures</p>";
        ?>
        <?php
        {{$prixTotal = 0;}}
        foreach($parcours->formations as $form){
            $prixTotal += $form->prixformation;
        }
        echo "<p class='simpleTextInParcours'><b>Prix total du parcours :</b> {$prixTotal} €</p>";
    ?>
        @if($parcours->certification != null)
            <p class="simpleTextInParcours"><b>Certification à la clef par :</b> {{$parcours->certification->organisme->nomorganisme}}</p>
        @endif
    </div>

    <h2 class="simpleTitleInParcours">Formations au programme :</h2>
    @foreach ($parcours->formations as $formation)
    <div id="{{$formation->idformation}}" class="formationInParcours">
       <h2 class="unselectable">{{$formation->titreformation}}</h2>
       <p class="unselectable">Niveau <b>{{$formation->niveauformation->nomniveau}}</b></p>
    </div>
        <h3 style="margin-left: 20px">Sequences</h3>
       @foreach ($formation->Sequence as $sequence)
        <div class="sequenceInParcours">
            <h3 style='display: inline-block'>{{$sequence->nomsequence}}</h3>
        <?php
        $url = $sequence->cheminressourcesequence;
        $directory = dirname($url);
        
        if(substr($directory, 0, strlen("/ressources/")) == "/ressources/"){
            $file = substr($directory, strlen("/ressources/"), strlen($directory)- strlen("/ressources/"));
            echo "<h3 style='display: inline-block'> - $file</h3>";
        }else {

            $parsedUrl = parse_url($url);
            $domain = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';
            echo "<h3 style='display: inline-block'> - $domain</h3>";
        }
        ?>   
        
        </div> 
       @endforeach
    @endforeach

    <script src="{{ asset('js/parcours.js') }}"></script>
    <script src="{{ asset('js/mainBar.js') }}"></script>
    <?php include(app_path().'/includes/footer.php'); ?>
</body>