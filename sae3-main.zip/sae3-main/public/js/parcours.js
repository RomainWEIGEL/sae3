let formations = document.querySelectorAll(".formationInParcours");

formations.forEach(form => {
    form.addEventListener("click", ()=> {
        document.location.href="/formation/"+form.id;
    })
});